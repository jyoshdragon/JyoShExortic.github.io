import { useState } from 'react';
import { CloudSun, Droplet, Sprout, ShieldAlert, Heart, CalendarClock, Sparkles, TrendingUp, AlertCircle, Thermometer } from 'lucide-react';
import { dbService } from '../dbService';
import { INITIAL_WEATHER_DASHBOARD } from '../mockData';

export default function FarmingDashboard() {
  const [data, setData] = useState(INITIAL_WEATHER_DASHBOARD);
  const [activeChartSource, setActiveChartSource] = useState<'flowering' | 'harvest'>('flowering');

  // Interactive toggle to stimulate moisture update
  const handleSimulateWatering = () => {
    setData((prev) => ({
      ...prev,
      soilMoisture: Math.min(100, prev.soilMoisture + 15),
      farmHealth: 'Excellent'
    }));
  };

  const handleEvaporate = () => {
    setData((prev) => ({
      ...prev,
      soilMoisture: Math.max(10, prev.soilMoisture - 12),
      farmHealth: prev.soilMoisture - 12 < 20 ? 'Needs Attention' : 'Good'
    }));
  };

  // SVG Chart layout calculation
  const maxVal = 120;
  const chartHeight = 120;
  const paddingX = 40;
  const spacingX = 64;

  return (
    <div className="py-6 px-4 max-w-6xl mx-auto space-y-6 font-sans">
      
      {/* Header and Telemetry stats */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <h1 className="text-2xl sm:text-3xl font-black text-[#1B3022] dark:text-[#F3F6F4] tracking-tight">Smart Farming Center</h1>
          <p className="text-[#1B3022]/70 dark:text-zinc-400 text-xs sm:text-sm font-medium">IoT telemetry data and automatic micro-watering scheduler.</p>
          
          {/* Owners Display */}
          <div className="flex flex-wrap items-center gap-2 pt-0.5">
            <span className="text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 bg-[#2D5A3F]/10 text-[#2D5A3F] dark:bg-[#2D5A3F]/20 dark:text-[#FF4D8D]/90 rounded-md">
              Farm Proprietors
            </span>
            <span className="text-xs font-semibold text-[#1B3022]/80 dark:text-zinc-350">
              Kumar Jyoti Narayan &amp; Santosh Behera
            </span>
          </div>
        </div>

        {/* Live coordinate tags */}
        <div className="flex items-center gap-2 bg-[#1B3022]/5 dark:bg-white/5 p-2.5 rounded-2xl text-[10px] font-mono font-bold text-[#1B3022]/70 dark:text-[#F3F6F4]/70 select-none">
          <span className="h-2 w-2 rounded-full bg-[#FF4D8D] animate-ping" />
          ESTATE GATEWAY: ACTIVE (3000)
        </div>
      </div>

      {/* Bento telemetry section grids */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* BOX 1: Live Weather widget */}
        <div className="bg-gradient-to-tr from-[#2D5A3F]/15 via-transparent to-transparent border border-[#1B3022]/10 dark:border-white/10 p-6 rounded-3xl relative overflow-hidden flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[10px] font-extrabold tracking-widest text-[#2D5A3F] uppercase">Ambient Station</span>
                <h3 className="font-extrabold text-sm text-[#1B3022] dark:text-zinc-100 mt-0.5">Weather Widget</h3>
              </div>
              <CloudSun className="h-9 w-9 text-[#FF4D8D] animate-bounce" />
            </div>

            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-black text-[#1B3022] dark:text-white">{data.temp}°C</span>
              <span className="text-xs font-semibold text-[#2D5A3F] uppercase tracking-widest">{data.condition}</span>
            </div>

            <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-snug">Vines active today. Slicing and tours conditions are highly pristine.</p>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-4 border-t border-[#1B3022]/10 dark:border-zinc-850 mt-4 text-[10px]">
            <div>
              <span className="text-zinc-400 block font-semibold uppercase">Est. Humidity</span>
              <span className="font-extrabold text-[#1B3022] dark:text-zinc-200">{data.humidity}%</span>
            </div>
            <div>
              <span className="text-zinc-400 block font-semibold uppercase">Solar Light</span>
              <span className="font-extrabold text-[#1B3022] dark:text-zinc-200">10.4 hrs</span>
            </div>
          </div>
        </div>

        {/* BOX 2: Soil Moisture Analyzer */}
        <div className="bg-[#ffffff] dark:bg-[#111e16] border border-[#1B3022]/10 dark:border-white/10 p-6 rounded-3xl flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[10px] font-extrabold tracking-widest text-zinc-400 uppercase">Subsurface IoT</span>
                <h3 className="font-extrabold text-sm text-[#1B3022] dark:text-zinc-100 mt-0.5">Soil Moisture Analytics</h3>
              </div>
              <Droplet className="h-6 w-6 text-indigo-500" />
            </div>

            {/* Dynamic gauge bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold text-[#1B3022] dark:text-zinc-300">
                <span>Moisture Ratio</span>
                <span className="font-extrabold text-[#2D5A3F] dark:text-[#FF4D8D]">{data.soilMoisture}%</span>
              </div>
              <div className="w-full bg-[#1B3022]/5 dark:bg-white/5 h-3.5 rounded-full overflow-hidden p-0.5">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    data.soilMoisture < 20 ? 'pink-gradient' : 'green-gradient'
                  }`}
                  style={{ width: `${data.soilMoisture}%` }}
                />
              </div>
            </div>

            {/* Smart simulator triggers */}
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={handleSimulateWatering}
                className="flex-1 py-1.5 rounded-full bg-[#2D5A3F]/10 hover:bg-[#2D5A3F]/20 text-[#1B3022] dark:text-[#FF4D8D] font-bold text-[10px] tracking-wide text-center cursor-pointer transition-colors"
              >
                Trigger Watering
              </button>
              <button
                onClick={handleEvaporate}
                className="flex-1 py-1.5 rounded-full bg-[#1B3022]/5 hover:bg-[#1B3022]/10 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400 font-semibold text-[10px] tracking-wide text-center cursor-pointer transition-colors"
                title="Simulate active summer water loss"
              >
                Evaporate Water
              </button>
            </div>
          </div>
        </div>

        {/* BOX 3: Farm Health Overview Dashboard */}
        <div className="bg-[#ffffff] dark:bg-[#111e16] border border-[#1B3022]/10 dark:border-white/10 p-6 rounded-3xl flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[10px] font-extrabold tracking-widest text-zinc-400 uppercase">Yield Guard</span>
                <h3 className="font-extrabold text-sm text-[#1B3022] dark:text-zinc-100 mt-0.5">Farm Health Summary</h3>
              </div>
              <Sprout className="h-6 w-6 text-[#2D5A3F]" />
            </div>

            <div className="flex items-center gap-3">
              <div className={`h-11 w-11 rounded-full flex items-center justify-center font-black ${
                data.farmHealth === 'Excellent'
                  ? 'bg-[#2D5A3F]/10 text-[#2D5A3F] dark:bg-[#2D5A3F]/30 dark:text-emerald-400'
                  : 'bg-amber-100 text-amber-600'
              }`}>
                {data.farmHealth === 'Excellent' ? '100' : '75'}
              </div>
              <div>
                <span className="text-xs font-bold text-[#1B3022] dark:text-zinc-200">{data.farmHealth} Condition</span>
                <p className="text-[10px] text-zinc-400 font-medium">Biological stress checks are normal.</p>
              </div>
            </div>
          </div>

          {/* Warning state notification alerts */}
          {data.soilMoisture < 20 ? (
            <div className="p-3 bg-[#FF4D8D]/15 rounded-2xl flex items-center gap-2 text-[10px] mt-4 text-red-600 leading-snug">
              <AlertCircle className="h-4.5 w-4.5 flex-shrink-0 animate-bounce" />
              <span>Warning: Soil hydration collapsed below threshold! Trigger drip emitters.</span>
            </div>
          ) : (
            <div className="p-3 bg-[#2D5A3F]/5 rounded-2xl flex items-center gap-2 text-[10px] mt-4 text-[#2D5A3F] dark:text-emerald-400 font-bold leading-snug">
              <Sparkles className="h-4 w-4" />
              <span>Moisture level optimized for potassium delivery and nutrient transport.</span>
            </div>
          )}
        </div>

      </div>

      {/* Analytics and Reminders section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Automatic scheduled watering reminders lists */}
        <div className="bg-[#ffffff] dark:bg-[#111e16] border border-[#1B3022]/10 dark:border-white/10 p-6 rounded-3xl space-y-4">
          <div className="flex items-center gap-2 border-b border-neutral-100 dark:border-zinc-850 pb-2">
            <CalendarClock className="h-5 w-5 text-[#FF4D8D]" />
            <h3 className="font-extrabold text-sm text-[#1B3022] dark:text-white">Watering Timers</h3>
          </div>

          <div className="space-y-3">
            {data.wateringReminders.map((re, idx) => (
              <div key={idx} className="flex justify-between items-center text-xs p-3.5 bg-[#1B3022]/5 dark:bg-zinc-950 rounded-2xl">
                <div>
                  <span className="font-extrabold text-[#1B3022] dark:text-zinc-200 block">{re.zone}</span>
                  <span className="text-[10px] text-zinc-400 font-bold">{re.time}</span>
                </div>
                <span className="px-2.5 py-1 bg-[#FF4D8D]/10 text-[#FF4D8D] font-extrabold rounded-full text-[9px] uppercase tracking-wide">
                  {re.duration}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Dynamic Crop Growth Tracking SVG chart */}
        <div className="md:col-span-2 bg-[#ffffff] dark:bg-[#111e16] border border-[#1B3022]/10 dark:border-white/10 p-6 rounded-3xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-100 dark:border-zinc-850 pb-2">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-[#2D5A3F] animate-pulse" />
              <h3 className="font-extrabold text-sm text-[#1B3022] dark:text-white">Soil Yield Analytics</h3>
            </div>

            {/* Selector toggle */}
            <div className="flex gap-1.5 self-start">
              <button
                onClick={() => setActiveChartSource('flowering')}
                className={`px-3.5 py-1.5 rounded-full text-[10px] font-bold cursor-pointer ${
                  activeChartSource === 'flowering' ? 'pink-gradient text-white shadow-sm' : 'text-zinc-450 dark:text-zinc-400'
                }`}
              >
                Bud Blooming
              </button>
              <button
                onClick={() => setActiveChartSource('harvest')}
                className={`px-3.5 py-1.5 rounded-full text-[10px] font-bold cursor-pointer ${
                  activeChartSource === 'harvest' ? 'green-gradient text-white shadow-sm' : 'text-zinc-455 dark:text-zinc-400'
                }`}
              >
                Fruit Harvested (kg)
              </button>
            </div>
          </div>

          {/* SVG custom interactive chart */}
          <div className="relative pt-6">
            <svg className="w-full" viewBox="0 0 450 150" fill="none">
              {/* Grid Lines */}
              <line x1="40" y1="20" x2="420" y2="20" stroke="#f1f5f9" className="dark:stroke-zinc-800/60" />
              <line x1="40" y1="70" x2="420" y2="70" stroke="#f1f5f9" className="dark:stroke-zinc-800/60" />
              <line x1="40" y1="120" x2="420" y2="120" stroke="#e2e8f0" className="dark:stroke-zinc-800" />

              {/* Chart Line Path */}
              {activeChartSource === 'flowering' ? (
                <>
                  {/* Flowering gradient */}
                  <path
                    d="M 40 125 L 104 110 L 168 105 L 232 85 L 296 65 L 360 35 L 424 20"
                    stroke="url(#flower-grad)"
                    strokeWidth="3.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  {/* Area fill */}
                  <path
                    d="M 40 120 L 40 125 L 104 110 L 168 105 L 232 85 L 296 65 L 360 35 L 424 20 L 424 120 Z"
                    fill="url(#area-flower)"
                    opacity="0.1"
                  />
                </>
              ) : (
                <>
                  {/* Harvest steps */}
                  <path
                    d="M 40 128 L 104 125 L 168 122 L 232 110 L 296 100 L 360 77 L 424 45"
                    stroke="url(#harvest-grad)"
                    strokeWidth="3.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  {/* Area fill */}
                  <path
                    d="M 40 120 L 40 128 L 104 125 L 168 122 L 232 110 L 296 100 L 360 77 L 424 45 L 424 120 Z"
                    fill="url(#area-harvest)"
                    opacity="0.1"
                  />
                </>
              )}

              {/* Data Node marker dots */}
              {data.growthStats.map((st, i) => {
                const val = activeChartSource === 'flowering' ? st.flowering : st.harvest;
                // Coordinate maths
                const cx = paddingX + i * spacingX;
                const cy = chartHeight - (val / maxVal) * chartHeight + 20;

                return (
                  <g key={i} className="group cursor-pointer">
                    <circle
                      cx={cx}
                      cy={cy}
                      r="4.5"
                      className={`${activeChartSource === 'flowering' ? 'fill-[#FF4D8D]' : 'fill-[#2D5A3F]'}`}
                    />
                    <circle
                      cx={cx}
                      cy={cy}
                      r="8"
                      className="fill-none stroke-current opacity-0 group-hover:opacity-30 text-[#FF4D8D]"
                    />
                    {/* Month Label */}
                    <text
                      x={cx}
                      y="142"
                      className="fill-zinc-400 font-mono text-[9px]"
                      textAnchor="middle"
                    >
                      {st.month}
                    </text>
                    {/* Tooltip values */}
                    <text
                      x={cx}
                      y={cy - 10}
                      className="text-[9px] font-bold fill-zinc-750 dark:fill-zinc-300 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity"
                      textAnchor="middle"
                    >
                      {val}
                    </text>
                  </g>
                );
              })}

              {/* Gradients */}
              <defs>
                <linearGradient id="flower-grad" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#FF4D8D" />
                  <stop offset="100%" stopColor="#D4145A" />
                </linearGradient>
                <linearGradient id="harvest-grad" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#1B3022" />
                  <stop offset="100%" stopColor="#2D5A3F" />
                </linearGradient>
                <linearGradient id="area-flower" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#FF4D8D" />
                  <stop offset="100%" stopColor="#FDFBF7" />
                </linearGradient>
                <linearGradient id="area-harvest" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2D5A3F" />
                  <stop offset="100%" stopColor="#FDFBF7" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </div>

      </div>

      {/* Footer / Domain Ownership */}
      <div className="pt-6 mt-8 border-t border-[#1B3022]/10 dark:border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] font-medium text-[#1B3022]/65 dark:text-zinc-500">
        <p>© 2026 JS Horticulture. All rights reserved.</p>
        <div className="flex items-center gap-1.5">
          <span className="opacity-80">Estates curated &amp; owned by:</span>
          <span className="font-bold text-[#1B3022] dark:text-[#F3F6F4] hover:text-[#FF4D8D] dark:hover:text-pink-400 transition-colors">Kumar Jyoti Narayan &amp; Santosh Behera</span>
        </div>
      </div>

    </div>
  );
}
