import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import configJson from '../firebase-applet-config.json';

let isFirebaseConfigured = false;
let db: any = null;
let auth: any = null;

try {
  // Validate if configurations are actually non-empty
  if (configJson && configJson.apiKey && configJson.projectId) {
    const app = getApps().length === 0 ? initializeApp(configJson) : getApp();
    db = getFirestore(app);
    auth = getAuth(app);
    isFirebaseConfigured = true;
    console.log("Firebase initialized successfully with credentials!");
  } else {
    console.log("No valid keys in firebase-applet-config.json. Defaulting to local storage persistence mode.");
  }
} catch (e) {
  console.warn("Could not initialze Firebase SDK, defaulting to offline sandbox mode.", e);
}

export { isFirebaseConfigured, db, auth };
