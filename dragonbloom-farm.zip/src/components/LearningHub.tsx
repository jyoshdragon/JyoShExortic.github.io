import React, { useState, useEffect, useRef } from 'react';
import { BookOpen, BookCheck, ThumbsUp, Sparkles, Send, Trash, MessagesSquare, PlayCircle, Star, GraduationCap } from 'lucide-react';
import { BlogPost, ChatMessage } from '../types';
import { dbService } from '../dbService';

const SUGGESTED_PROMPTS = [
  'How often do I need to water my dragon fruit vines?',
  'What fertilizer schedule triggers massive spring flowering?',
  'How can I get rid of scale insects organically?',
  'When exactly is a pitaya ready for harvesting?'
];

const VIDEO_LECTURES = [
  {
    id: 'v1',
    title: 'Beginners Guide to Trellis and Canopy Architecture',
    level: 'Beginner',
    duration: '12 mins',
    image: 'https://images.unsplash.com/photo-1516253593875-bd7ba052fbc5?w=600&auto=format&fit=crop'
  },
  {
    id: 'v2',
    title: 'Grafting Techniques for Yellow and Red Varieties',
    level: 'Advanced',
    duration: '18 mins',
    image: 'https://images.unsplash.com/photo-1463123081488-729f555bc3f1?w=600&auto=format&fit=crop'
  }
];

export default function LearningHub() {
  const [blogs, setBlogs] = useState<BlogPost[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedBlog, setSelectedBlog] = useState<BlogPost | null>(null);

  // Chat states
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const loadBlogs = () => {
    dbService.getBlogs().then(list => setBlogs(list));
  };

  useEffect(() => {
    loadBlogs();
    
    // Default chat greetings
    setChatMessages([
      {
        id: 'welcome',
        sender: 'assistant',
        text: "Greetings pitaya grower! I am JS Horticulture, your direct AI agricultural consultant. Ask me anything about micro-irrigation, fertilizer schedules, nesting pests, or sunset visits!",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  }, []);

  // Scroll details
  useEffect(() => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTop = scrollContainerRef.current.scrollHeight;
    }
  }, [chatMessages, isChatLoading]);

  // Handle Likes
  const handleLikeBlog = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await dbService.likeBlog(id);
      loadBlogs();
      if (selectedBlog && selectedBlog.id === id) {
        setSelectedBlog(prev => prev ? { ...prev, likes: prev.likes + 1 } : null);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Chat Trigger
  const handleSendMessage = async (text: string) => {
    if (!text.trim()) return;
    
    const userMsg: ChatMessage = {
      id: 'usr_' + Date.now(),
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages(prev => [...prev, userMsg]);
    setChatInput('');
    setIsChatLoading(true);

    try {
      const reply = await dbService.askAI(userMsg.text);
      const aiMsg: ChatMessage = {
        id: 'ai_' + Date.now(),
        sender: 'assistant',
        text: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setChatMessages(prev => [...prev, aiMsg]);
    } catch {
      // safe fallback
    } finally {
      setIsChatLoading(false);
    }
  };

  const clearChat = () => {
    setChatMessages([
      {
        id: 'welcome',
        sender: 'assistant',
        text: "Chat timeline cleared. Ask me a new agricultural question!",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  const filteredBlogs = blogs.filter(b => selectedCategory === 'All' || b.category === selectedCategory);

  return (
    <div className="py-6 px-4 max-w-6xl mx-auto space-y-8">
      
      {/* 1. Header description */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-black text-neutral-900 dark:text-zinc-100 tracking-tight">Dragon Fruit Hortus Hub</h1>
        <p className="text-zinc-500 dark:text-zinc-400 text-xs sm:text-sm">Acquire world-class skills from horticulturalists at our pitaya estate.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* LEFT COLUMN/MID COLUMN: BLOGS & VIDEOS */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Sub Categories for tutorials */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-neutral-100 dark:border-zinc-800">
            {['All', 'Farming Tutorial', 'Pest Control', 'Irrigation Methods', 'Fertilizer Guide'].map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 text-xs font-bold rounded-full transition-all whitespace-nowrap cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-neutral-50 dark:bg-zinc-900 text-zinc-600 dark:text-zinc-400 hover:bg-neutral-100 dark:hover:bg-zinc-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Blogs display or detailed reading */}
          {selectedBlog ? (
            <div className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800 p-6 rounded-3xl space-y-4 shadow-sm animate-fade-in">
              <button
                onClick={() => setSelectedBlog(null)}
                className="text-xs font-bold text-pink-500 hover:text-pink-600 cursor-pointer"
              >
                ← Back to Articles list
              </button>
              
              <div className="space-y-4">
                <img
                  src={selectedBlog.image}
                  alt={selectedBlog.title}
                  className="w-full h-64 object-cover rounded-2xl bg-neutral-100 dark:bg-zinc-950"
                />

                <div className="flex items-center justify-between text-[10px] font-bold text-zinc-400 uppercase tracking-widest pt-2">
                  <span>{selectedBlog.category}</span>
                  <span>{selectedBlog.readTime}</span>
                </div>

                <h2 className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-zinc-100 leading-tight">
                  {selectedBlog.title}
                </h2>

                <p className="text-xs text-zinc-400 font-medium">Published by: {selectedBlog.author} on {new Date(selectedBlog.date).toLocaleDateString()}</p>

                {/* Simulated markdown rendering block */}
                <div className="prose dark:prose-invert max-w-none text-xs sm:text-sm text-zinc-700 dark:text-zinc-300 leading-relaxed space-y-4 whitespace-pre-line border-t border-neutral-100 dark:border-zinc-800 pt-4">
                  {selectedBlog.content}
                </div>

                <div className="flex items-center gap-2 pt-4 border-t border-neutral-100 dark:border-zinc-800 justify-between">
                  <button
                    onClick={(e) => handleLikeBlog(selectedBlog.id, e)}
                    className="flex items-center gap-1.5 px-4 py-2 bg-neutral-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 rounded-full font-bold text-xs cursor-pointer"
                  >
                    <ThumbsUp className="h-4 w-4 text-pink-500" />
                    Helpful ({selectedBlog.likes})
                  </button>
                  <button
                    onClick={() => setSelectedBlog(null)}
                    className="text-xs font-bold text-zinc-400 hover:text-zinc-500"
                  >
                    Close Article
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-6">
              {filteredBlogs.map((b) => (
                <div
                  key={b.id}
                  onClick={() => setSelectedBlog(b)}
                  className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800/60 rounded-3xl overflow-hidden shadow-sm hover:shadow-md transition-shadow cursor-pointer flex flex-col sm:flex-row gap-4 p-4"
                >
                  <img
                    src={b.image}
                    alt={b.title}
                    className="w-full sm:w-40 h-32 object-cover rounded-2xl bg-neutral-100 dark:bg-zinc-950 flex-shrink-0"
                  />
                  
                  <div className="flex-1 flex flex-col justify-between py-1 space-y-2">
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-[9px] font-bold text-zinc-400 uppercase tracking-widest">
                        <span>{b.category}</span>
                        <span>{b.readTime}</span>
                      </div>
                      <h3 className="font-extrabold text-neutral-900 dark:text-zinc-100 text-sm sm:text-base leading-snug">
                        {b.title}
                      </h3>
                      <p className="text-[11px] text-zinc-500 dark:text-zinc-400 line-clamp-2 leading-relaxed">
                        {b.summary}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <span className="text-[10px] text-zinc-400">By {b.author}</span>
                      <button
                        onClick={(e) => handleLikeBlog(b.id, e)}
                        className="flex items-center gap-1 text-[11px] font-bold text-zinc-500 hover:text-pink-500 cursor-pointer"
                      >
                        <ThumbsUp className="h-4 w-4 text-pink-500" />
                        Like ({b.likes})
                      </button>
                    </div>
                  </div>

                </div>
              ))}
            </div>
          )}

          {/* Video Lessons Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <GraduationCap className="h-5 w-5 text-pink-500" />
              <h3 className="font-extrabold text-sm text-neutral-800 dark:text-zinc-100">Video Masterclasses</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {VIDEO_LECTURES.map((vid) => (
                <div
                  key={vid.id}
                  className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800 rounded-3xl p-4 shadow-sm relative group overflow-hidden"
                >
                  <div className="relative aspect-video rounded-2xl overflow-hidden bg-neutral-100 dark:bg-zinc-950">
                    <img
                      src={vid.image}
                      alt={vid.title}
                      className="w-full h-full object-cover brightness-90 group-hover:scale-102 transition-all duration-300"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <PlayCircle className="h-12 w-12 text-white/90 drop-shadow-md cursor-pointer animate-pulse" />
                    </div>
                  </div>
                  <div className="pt-3 space-y-1">
                    <div className="flex justify-between items-center text-[9px] font-bold uppercase tracking-wider text-zinc-400">
                      <span>{vid.level}</span>
                      <span>{vid.duration}</span>
                    </div>
                    <h4 className="font-bold text-xs text-zinc-900 dark:text-zinc-100 line-clamp-1">{vid.title}</h4>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: AI FARMING CHATBOT ASSISTANT */}
        <div className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800/80 rounded-3xl shadow-sm h-[600px] flex flex-col justify-between overflow-hidden">
          
          {/* Chat Assistant Header */}
          <div className="bg-gradient-to-r from-emerald-950/20 via-pink-900/15 to-transparent border-b border-neutral-100 dark:border-zinc-800 p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-emerald-600 text-white flex items-center justify-center relative font-bold text-xs select-none">
                <Sparkles className="h-4.5 w-4.5 text-accent animate-spin" />
              </div>
              <div>
                <h3 className="text-xs font-black text-neutral-800 dark:text-zinc-100 block tracking-tight">Consultant Expert AI</h3>
                <span className="text-[9px] text-zinc-400 leading-none">Powered by Gemini 3.5</span>
              </div>
            </div>

            <button
              onClick={clearChat}
              className="text-[10px] uppercase font-bold text-zinc-400 hover:text-red-500 flex items-center gap-1 cursor-pointer"
              title="Clear timeline"
            >
              <Trash className="h-3.5 w-3.5" />
              Clear
            </button>
          </div>

          {/* Messages timeline area */}
          <div
            ref={scrollContainerRef}
            className="flex-1 p-4 overflow-y-auto space-y-4 scrollbar-none"
          >
            {chatMessages.map((msg) => {
              const isAss = msg.sender === 'assistant';
              return (
                <div key={msg.id} className={`flex ${isAss ? 'justify-start' : 'justify-end'}`}>
                  <div className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-xs shadow-sm leading-relaxed ${
                    isAss
                      ? 'bg-neutral-100 dark:bg-zinc-800/80 text-zinc-800 dark:text-zinc-200 rounded-tl-none'
                      : 'bg-emerald-600 text-white rounded-tr-none font-medium'
                  }`}>
                    <p className="whitespace-pre-line">{msg.text}</p>
                    <span className="block text-[9px] opacity-60 text-right mt-1.5">{msg.timestamp}</span>
                  </div>
                </div>
              );
            })}

            {isChatLoading && (
              <div className="flex justify-start">
                <div className="bg-neutral-100 dark:bg-zinc-800/80 rounded-xl rounded-tl-none px-4 py-3 flex items-center gap-2 text-zinc-400 text-xs shadow-sm">
                  <span className="h-2 w-2 rounded-full bg-pink-500 animate-bounce" />
                  <span className="h-2 w-2 rounded-full bg-pink-500 animate-bounce delay-150" />
                  <span className="h-2 w-2 rounded-full bg-pink-500 animate-bounce delay-300" />
                  <span className="text-[10px] leading-none ml-1">Drafting advice...</span>
                </div>
              </div>
            )}
          </div>

          {/* Prompt Suggestion box list */}
          <div className="px-4 py-2 border-t border-neutral-100 dark:border-zinc-800/50 flex flex-nowrap gap-1.5 overflow-x-auto scrollbar-none">
            {SUGGESTED_PROMPTS.map((spr, i) => (
              <button
                key={i}
                type="button"
                onClick={() => handleSendMessage(spr)}
                className="px-2.5 py-1 rounded-full bg-neutral-50 dark:bg-zinc-800 border-none text-[10px] font-bold text-zinc-500 hover:text-pink-500 whitespace-nowrap cursor-pointer transition-colors"
              >
                {spr.substring(0, 22) + '...'}
              </button>
            ))}
          </div>

          {/* Chat Form input */}
          <div className="p-3 border-t border-neutral-100 dark:border-zinc-800/80 bg-neutral-50 dark:bg-zinc-950">
            <div className="flex items-center gap-1.5 bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800 rounded-full px-3 py-1.5">
              <label htmlFor="ai-chat-input" className="sr-only">Ask AI farming question</label>
              <input
                id="ai-chat-input"
                type="text"
                placeholder="Ask smart farm consultant..."
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage(chatInput)}
                className="flex-1 text-xs sm:text-sm border-none outline-none text-zinc-800 dark:text-zinc-100 bg-transparent py-1"
              />
              <button
                onClick={() => handleSendMessage(chatInput)}
                className="p-1.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs cursor-pointer"
                title="Send active message"
              >
                <Send className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
