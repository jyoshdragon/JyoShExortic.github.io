import { Product, BlogPost, Booking, Order, UserProfile, UserRole, WeatherData, ChatMessage, CartItem } from './types';
import { INITIAL_PRODUCTS, INITIAL_BLOG_POSTS, INITIAL_WEATHER_DASHBOARD } from './mockData';
import { doc, getDoc, setDoc, collection, getDocs, updateDoc, addDoc, query, where, onSnapshot } from 'firebase/firestore';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import { isFirebaseConfigured, db, auth } from './firebase';

// Local storage keys
const USERS_KEY = 'js_horticulture_users';
const CURRENT_USER_KEY = 'js_horticulture_current_user';
const PRODUCTS_KEY = 'js_horticulture_products';
const BOOKINGS_KEY = 'js_horticulture_bookings';
const ORDERS_KEY = 'js_horticulture_orders';
const WISHLIST_KEY = 'js_horticulture_wishlist';
const BLOGS_KEY = 'js_horticulture_blogs';

// Exception helper for Firebase integration skill conforming to FirestoreErrorInfo structure
enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: any;
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid || null,
      email: auth?.currentUser?.email || null,
      emailVerified: auth?.currentUser?.emailVerified || null,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// ----------------------------------------------------
// LOCAL FALLBACK DATA HELPERS
// ----------------------------------------------------
const initLocalStorage = () => {
  if (!localStorage.getItem(PRODUCTS_KEY)) {
    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(INITIAL_PRODUCTS));
  }
  if (!localStorage.getItem(BLOGS_KEY)) {
    localStorage.setItem(BLOGS_KEY, JSON.stringify(INITIAL_BLOG_POSTS));
  }
  if (!localStorage.getItem(BOOKINGS_KEY)) {
    localStorage.setItem(BOOKINGS_KEY, JSON.stringify([]));
  }
  if (!localStorage.getItem(ORDERS_KEY)) {
    localStorage.setItem(ORDERS_KEY, JSON.stringify([]));
  }
  if (!localStorage.getItem(WISHLIST_KEY)) {
    localStorage.setItem(WISHLIST_KEY, JSON.stringify([]));
  }
  if (!localStorage.getItem(CURRENT_USER_KEY)) {
    // Default logged-in premium user to showcase full app features immediately
    const defaultCustomer: UserProfile = {
      uid: 'c1',
      email: 'kumarsoumyanarayan2@gmail.com',
      displayName: 'Kumar Soumyanarayan',
      role: 'Admin', // Give them admin out of the box so they can play with the Admin screen!
      loyaltyPoints: 120,
      referralCode: 'BLOOM120',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80'
    };
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(defaultCustomer));
    localStorage.setItem(USERS_KEY, JSON.stringify({ 'c1': defaultCustomer }));
  }
};

if (typeof window !== 'undefined') {
  initLocalStorage();
}

// ----------------------------------------------------
// MAIN DB SERVICE INTERFACE
// ----------------------------------------------------
export const dbService = {
  // Auth Services
  getCurrentUser(): UserProfile | null {
    if (typeof window === 'undefined') return null;
    const user = localStorage.getItem(CURRENT_USER_KEY);
    return user ? JSON.parse(user) : null;
  },

  async login(email: string, role: UserRole = 'Customer'): Promise<UserProfile> {
    if (isFirebaseConfigured && auth) {
      try {
        // Authenticate standard flows or log in simulated
        // We do a simulated authentication mapping to firestore for a unified flow
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'auth');
      }
    }

    // High fidelity simulated login
    const formattedEmail = email.trim().toLowerCase();
    const mockId = 'user_' + Math.random().toString(36).substr(2, 9);
    
    // Look up or save profile
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
    let matchedUser = Object.values(users).find((u: any) => u.email.toLowerCase() === formattedEmail) as UserProfile | undefined;
    
    if (!matchedUser) {
      matchedUser = {
        uid: mockId,
        email: formattedEmail,
        displayName: formattedEmail.split('@')[0].toUpperCase(),
        role: formattedEmail.includes('admin') ? 'Admin' : formattedEmail.includes('worker') ? 'Farm Worker' : role,
        loyaltyPoints: 50,
        referralCode: `BLOOM${Math.floor(100 + Math.random() * 900)}`,
        avatarUrl: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80`
      };
      users[matchedUser.uid] = matchedUser;
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
    }
    
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(matchedUser));
    return matchedUser;
  },

  logout(): void {
    localStorage.removeItem(CURRENT_USER_KEY);
    if (isFirebaseConfigured && auth) {
      signOut(auth).catch(err => console.error(err));
    }
  },

  async switchRole(role: UserRole): Promise<UserProfile | null> {
    const user = this.getCurrentUser();
    if (!user) return null;
    
    const updated = { ...user, role };
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(updated));
    
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
    users[updated.uid] = updated;
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    return updated;
  },

  // Products
  async getProducts(): Promise<Product[]> {
    if (isFirebaseConfigured && db) {
      try {
        const querySnapshot = await getDocs(collection(db, 'products'));
        if (querySnapshot.size > 0) {
          const list: Product[] = [];
          querySnapshot.forEach((docSnap) => {
            list.push({ id: docSnap.id, ...docSnap.data() } as Product);
          });
          return list;
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'products');
      }
    }
    return JSON.parse(localStorage.getItem(PRODUCTS_KEY) || '[]');
  },

  async updateProduct(product: Product): Promise<Product> {
    if (isFirebaseConfigured && db) {
      try {
        await setDoc(doc(db, 'products', product.id), product);
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, `products/${product.id}`);
      }
    }
    const products = JSON.parse(localStorage.getItem(PRODUCTS_KEY) || '[]');
    const index = products.findIndex((p: Product) => p.id === product.id);
    if (index > -1) {
      products[index] = product;
    } else {
      products.push(product);
    }
    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));
    return product;
  },

  // Wishlist
  getWishlist(): string[] {
    if (typeof window === 'undefined') return [];
    return JSON.parse(localStorage.getItem(WISHLIST_KEY) || '[]');
  },

  toggleWishlist(productId: string): string[] {
    const list = this.getWishlist();
    const index = list.indexOf(productId);
    if (index > -1) {
      list.splice(index, 1);
    } else {
      list.push(productId);
    }
    localStorage.setItem(WISHLIST_KEY, JSON.stringify(list));
    return list;
  },

  // Visit Bookings
  async getBookings(): Promise<Booking[]> {
    if (isFirebaseConfigured && db) {
      try {
        const querySnapshot = await getDocs(collection(db, 'bookings'));
        const list: Booking[] = [];
        querySnapshot.forEach((docRef) => {
          list.push({ id: docRef.id, ...docRef.data() } as Booking);
        });
        return list;
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'bookings');
      }
    }
    return JSON.parse(localStorage.getItem(BOOKINGS_KEY) || '[]');
  },

  async createBooking(bookingData: Omit<Booking, 'id' | 'status' | 'qrCode' | 'createdAt'>): Promise<Booking> {
    const bookingId = 'bk_' + Math.floor(1000 + Math.random() * 9000);
    const newBooking: Booking = {
      ...bookingData,
      id: bookingId,
      status: 'pending',
      qrCode: `DRAGONBLOOM-TOUR:${bookingId}`,
      createdAt: new Date().toISOString()
    };

    if (isFirebaseConfigured && db) {
      try {
        await setDoc(doc(db, 'bookings', bookingId), newBooking);
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, `bookings/${bookingId}`);
      }
    }

    const bookings = JSON.parse(localStorage.getItem(BOOKINGS_KEY) || '[]');
    bookings.push(newBooking);
    localStorage.setItem(BOOKINGS_KEY, JSON.stringify(bookings));
    return newBooking;
  },

  async updateBookingStatus(bookingId: string, status: 'approved' | 'rejected'): Promise<Booking> {
    if (isFirebaseConfigured && db) {
      try {
        const docRef = doc(db, 'bookings', bookingId);
        await updateDoc(docRef, { status });
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, `bookings/${bookingId}`);
      }
    }

    const bookings = JSON.parse(localStorage.getItem(BOOKINGS_KEY) || '[]');
    const index = bookings.findIndex((b: Booking) => b.id === bookingId);
    if (index > -1) {
      bookings[index].status = status;
      localStorage.setItem(BOOKINGS_KEY, JSON.stringify(bookings));
      return bookings[index];
    }
    throw new Error('Booking not found');
  },

  // E-Commerce Orders
  async getOrders(): Promise<Order[]> {
    if (isFirebaseConfigured && db) {
      try {
        const querySnapshot = await getDocs(collection(db, 'orders'));
        const list: Order[] = [];
        querySnapshot.forEach((docRef) => {
          list.push({ id: docRef.id, ...docRef.data() } as Order);
        });
        return list;
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'orders');
      }
    }
    return JSON.parse(localStorage.getItem(ORDERS_KEY) || '[]');
  },

  async createOrder(orderData: Omit<Order, 'id' | 'createdAt' | 'updatedAt' | 'invoiceUrl'>): Promise<Order> {
    const orderId = 'ORD-' + Math.floor(10000 + Math.random() * 90000);
    const invoiceUrl = `/invoice/${orderId}`;
    const newOrder: Order = {
      ...orderData,
      id: orderId,
      invoiceUrl,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // Reduce stock locally
    const products = JSON.parse(localStorage.getItem(PRODUCTS_KEY) || '[]');
    newOrder.items.forEach(item => {
      const pIdx = products.findIndex((p: Product) => p.id === item.product.id);
      if (pIdx > -1) {
        products[pIdx].stock = Math.max(0, products[pIdx].stock - item.quantity);
      }
    });
    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));

    // Increase Loyalty Points
    const user = this.getCurrentUser();
    if (user && user.uid === orderData.userId) {
      const earnedPoints = Math.floor(newOrder.total * 5); // 5 points per dollar
      user.loyaltyPoints += earnedPoints;
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
      const users = JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
      users[user.uid] = user;
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
    }

    if (isFirebaseConfigured && db) {
      try {
        await setDoc(doc(db, 'orders', orderId), newOrder);
        // Also update products and user limits on Firestore if enabled
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, `orders/${orderId}`);
      }
    }

    const orders = JSON.parse(localStorage.getItem(ORDERS_KEY) || '[]');
    orders.unshift(newOrder); // Newest first
    localStorage.setItem(ORDERS_KEY, JSON.stringify(orders));
    return newOrder;
  },

  // Educational Blogs
  async getBlogs(): Promise<BlogPost[]> {
    return JSON.parse(localStorage.getItem(BLOGS_KEY) || '[]');
  },

  async likeBlog(id: string): Promise<BlogPost> {
    const blogs = JSON.parse(localStorage.getItem(BLOGS_KEY) || '[]');
    const index = blogs.findIndex((b: BlogPost) => b.id === id);
    if (index > -1) {
      blogs[index].likes += 1;
      localStorage.setItem(BLOGS_KEY, JSON.stringify(blogs));
      return blogs[index];
    }
    throw new Error('Blog not found');
  },

  // AI Chat Farming Queries proxy
  async askAI(prompt: string): Promise<string> {
    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ prompt })
      });
      if (!response.ok) {
        throw new Error('Error in API gateway');
      }
      const data = await response.json();
      return data.reply;
    } catch (e) {
      console.warn("API chatbot server error, generating intelligent offline agriculture advice.", e);
      // Beautiful offline smart auto-responses
      const lower = prompt.toLowerCase();
      if (lower.includes('water') || lower.includes('irrigation')) {
        return "Hi there! For our Dragon Fruits at JS Horticulture, we use micro-drip emitters. We highly recommend watering early in the morning around 6:30 AM to prevent scorching. Deliver 1.5 gallons per vine, 3 times/week in summer, and drop down to 0.5 gallons every 10 days in winter. Ensure your sandy-loam soil remains well-draining!";
      }
      if (lower.includes('fertilizer') || lower.includes('feed') || lower.includes('compost')) {
        return "Ah, premium growth! Throughout active vegetative growth (late winter), heavy compost or cow manure provides rich nitrogen for stem girth. But when blooming approaches in mid-spring, switch to a phosphorus-rich organic mix (like trace bone meal and potash) to support giant flowers and high brix-count fruits.";
      }
      if (lower.includes('pest') || lower.includes('ant') || lower.includes('bug')) {
        return "Our eco-specialists at JS Horticulture swear by systemic organic repellents. Mix 2 tbsp cold-pressed organic neem oil + 1 tbsp vegetable liquid soap in a gallon of warm water. Spray in the late evening. For ants, apply food-grade Diatomaceous Earth around trellis stakes to disrupt their crawling tracks naturally!";
      }
      if (lower.includes('harvest') || lower.includes('pick') || lower.includes('ready')) {
        return "A dragon fruit is ready for harvest exactly 28 to 32 days after active flower pollination. Real ripeness displays a vivid color shift of the skin matching the flaps, and the outer scale tips just begin to wrinkle slightly. Cut cleanly at the node using sterile stainless pruning shears!";
      }
      return "Hello Pitaya grower! JS Horticulture's AI assistant is here to help you cultivate premium organic fruits. Ask me about micro-irrigation, fertilizer calculations, natural pest prevention, post-harvest handling, or visit bookings!";
    }
  },

  // Dashboard Stats
  async getDashboardAnalytics() {
    const orders = await this.getOrders();
    const products = await this.getProducts();
    const bookings = await this.getBookings();

    const totalRevenue = orders
      .filter(o => o.status !== 'cancelled')
      .reduce((sum, o) => sum + o.total, 0);

    const activeBookingsCount = bookings.filter(b => b.status === 'pending').length;
    const approvedBookingsCount = bookings.filter(b => b.status === 'approved').length;

    // Category distribution
    const categoryCount: Record<string, number> = {};
    products.forEach(p => {
      categoryCount[p.category] = (categoryCount[p.category] || 0) + 1;
    });

    return {
      totalRevenue,
      ordersCount: orders.length,
      productsCount: products.length,
      bookingsCount: bookings.length,
      activeBookingsCount,
      approvedBookingsCount,
      recentOrders: orders.slice(0, 5),
      recentBookings: bookings.slice(0, 5),
      productsStock: products.map(p => ({ name: p.name, stock: p.stock, price: p.price }))
    };
  },

  // Shopping Cart Persistence Managers
  getCart(): CartItem[] {
    if (typeof window === 'undefined') return [];
    return JSON.parse(localStorage.getItem('js_horticulture_cart') || '[]');
  },

  addToCart(product: Product): CartItem {
    const list = this.getCart();
    const existing = list.find((it) => it.product.id === product.id);
    let result: CartItem;
    if (existing) {
      existing.quantity += 1;
      result = existing;
    } else {
      const newItem = { product, quantity: 1 };
      list.push(newItem);
      result = newItem;
    }
    localStorage.setItem('js_horticulture_cart', JSON.stringify(list));
    return result;
  },

  updateCartQuantity(productId: string, delta: number): void {
    const list = this.getCart();
    const existing = list.find((it) => it.product.id === productId);
    if (existing) {
      existing.quantity = Math.max(1, existing.quantity + delta);
      localStorage.setItem('js_horticulture_cart', JSON.stringify(list));
    }
  },

  removeFromCart(productId: string): void {
    const list = this.getCart();
    const filtered = list.filter((it) => it.product.id !== productId);
    localStorage.setItem('js_horticulture_cart', JSON.stringify(filtered));
  },

  clearCart(): void {
    localStorage.setItem('js_horticulture_cart', JSON.stringify([]));
  },

  // Swapped Workspace sessions
  setDemoSession(role: UserRole, email: string = 'reviewer@jshorticulture.com'): UserProfile {
    const keyUser: UserProfile = {
      uid: role === 'Admin' ? 'admin_test' : role === 'Farm Worker' ? 'worker_test' : 'customer_test',
      email,
      displayName: role === 'Admin' ? 'Admin Director' : role === 'Farm Worker' ? 'Senior Harvester' : 'Kumar Soumyanarayan',
      role,
      loyaltyPoints: role === 'Admin' ? 999 : role === 'Farm Worker' ? 250 : 120,
      referralCode: 'GOLDEN2026',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80'
    };
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(keyUser));
    return keyUser;
  },

  clearSession(): void {
    localStorage.removeItem(CURRENT_USER_KEY);
  },

  // Contact Inquiries logs
  async getContactMessages(): Promise<any[]> {
    if (typeof window === 'undefined') return [];
    const list = localStorage.getItem('js_horticulture_messages');
    if (!list) {
      const seeds = [
        {
          id: 'msg_1',
          name: 'Chef Michel L\'Aura',
          email: 'laura@oasis.com',
          text: 'Need to inquire about wholesale logistics for delivering 200kg of Royal Magenta monthly starting from next week. Do you supply custom wood crates?',
          createdAt: new Date().toISOString()
        }
      ];
      localStorage.setItem('js_horticulture_messages', JSON.stringify(seeds));
      return seeds;
    }
    return JSON.parse(list);
  },

  async createContactMessage(data: { name: string, email: string, text: string }) {
    const list = await this.getContactMessages();
    const newMsg = {
      ...data,
      id: 'msg_' + Date.now(),
      createdAt: new Date().toISOString()
    };
    list.unshift(newMsg);
    localStorage.setItem('js_horticulture_messages', JSON.stringify(list));
    return newMsg;
  },

  async deleteContactMessage(id: string): Promise<void> {
    const list = await this.getContactMessages();
    const filtered = list.filter((m) => m.id !== id);
    localStorage.setItem('js_horticulture_messages', JSON.stringify(filtered));
  },

  // User Lookups Ledger
  async getSystemUsers(): Promise<UserProfile[]> {
    const listStr = localStorage.getItem(USERS_KEY);
    const usersObj = listStr ? JSON.parse(listStr) : {};
    const defaults = [
      { uid: 'admin_test', email: 'director@jshorticulture.com', displayName: 'Admin Director', role: 'Admin' as const, loyaltyPoints: 999, referralCode: 'CEO100', avatarUrl: '' },
      { uid: 'worker_test', email: 'harvester@jshorticulture.com', displayName: 'Senior Harvester', role: 'Farm Worker' as const, loyaltyPoints: 250, referralCode: 'SOIL5', avatarUrl: '' },
      { uid: 'c1', email: 'kumarsoumyanarayan2@gmail.com', displayName: 'Kumar Soumyanarayan', role: 'Customer' as const, loyaltyPoints: 120, referralCode: 'BLOOM120', avatarUrl: '' }
    ];
    defaults.forEach(d => {
      if (!usersObj[d.uid]) {
        usersObj[d.uid] = d;
      }
    });
    localStorage.setItem(USERS_KEY, JSON.stringify(usersObj));
    return Object.values(usersObj);
  },

  // Catalog insertions & custom stock controls
  async createProduct(productData: Omit<Product, 'id'>): Promise<Product> {
    const id = 'prod_' + Math.floor(100 + Math.random() * 900);
    const newPr = { ...productData, id };
    const list = JSON.parse(localStorage.getItem(PRODUCTS_KEY) || '[]');
    list.push(newPr);
    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(list));
    return newPr;
  },

  async updateProductStock(productId: string, delta: number): Promise<Product> {
    const list = JSON.parse(localStorage.getItem(PRODUCTS_KEY) || '[]');
    const idx = list.findIndex((p: Product) => p.id === productId);
    if (idx > -1) {
      list[idx].stock = Math.max(0, list[idx].stock + delta);
      localStorage.setItem(PRODUCTS_KEY, JSON.stringify(list));
      return list[idx];
    }
    throw new Error('Product not found');
  },

  async updateOrderStatus(orderId: string, status: 'ordered' | 'processing' | 'shipped' | 'delivered'): Promise<Order> {
    const list = JSON.parse(localStorage.getItem(ORDERS_KEY) || '[]');
    const idx = list.findIndex((o: Order) => o.id === orderId);
    if (idx > -1) {
      list[idx].status = status;
      list[idx].updatedAt = new Date().toISOString();
      localStorage.setItem(ORDERS_KEY, JSON.stringify(list));
      return list[idx];
    }
    throw new Error('Order not found');
  }
};
