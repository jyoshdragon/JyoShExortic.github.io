export type UserRole = 'Customer' | 'Farm Worker' | 'Admin';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  loyaltyPoints: number;
  referralCode: string;
  referredBy?: string;
  avatarUrl?: string;
}

export type ProductCategory = 'Fresh Fruits' | 'Organic Juice' | 'Dragon Fruit Jam' | 'Plants & Saplings' | 'Farm Compost';

export interface Product {
  id: string;
  name: string;
  description: string;
  category: ProductCategory;
  price: number;
  stock: number;
  rating: number;
  ratingsCount: number;
  image: string;
  isPopular?: boolean;
  wateringFrequency?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Booking {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  date: string;
  timeSlot: string;
  visitorsCount: number;
  status: 'pending' | 'approved' | 'rejected';
  qrCode: string; // Base64 data or unique key representing QR code content
  createdAt: string;
}

export interface BlogPost {
  id: string;
  title: string;
  summary: string;
  content: string; // Markdown supported content
  category: 'Farming Tutorial' | 'Pest Control' | 'Irrigation Methods' | 'Fertilizer Guide' | 'General Info';
  author: string;
  date: string;
  readTime: string;
  image: string;
  likes: number;
}

export interface WeatherData {
  temp: number;
  condition: 'Sunny' | 'Partly Cloudy' | 'Rainy' | 'Humid';
  humidity: number;
  soilMoisture: number; // Percentage
  farmHealth: 'Excellent' | 'Good' | 'Needs Attention';
  wateringReminders: {
    time: string;
    zone: string;
    duration: string;
  }[];
  growthStats: {
    month: string;
    flowering: number;
    harvest: number;
  }[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  status: 'ordered' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  shippingAddress: {
    fullName: string;
    addressLine: string;
    city: string;
    postalCode: string;
    phone: string;
  };
  paymentMethod: 'card' | 'upi' | 'wallet';
  paymentId?: string;
  invoiceUrl?: string;
  createdAt: string;
  updatedAt: string;
}
