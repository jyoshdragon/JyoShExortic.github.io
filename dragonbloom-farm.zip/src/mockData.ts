import { Product, BlogPost, WeatherData } from './types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'p1',
    name: 'Royal Magenta Dragon Fruit',
    description: 'Freshly harvested, organic red-fleshed dragon fruit. Exceptionally sweet flavor profile with high antioxidant and nutrient content.',
    category: 'Fresh Fruits',
    price: 8.99,
    stock: 25,
    rating: 4.9,
    ratingsCount: 48,
    image: 'https://images.unsplash.com/photo-1584589167171-541ce45f1eea?w=600&auto=format&fit=crop&q=80',
    isPopular: true
  },
  {
    id: 'p2',
    name: 'Golden Solar Dragon Fruit',
    description: 'Rare yellow-skinned dragon fruit with super-sweet white flesh. Refreshing taste directly from our elite greenhouse lines.',
    category: 'Fresh Fruits',
    price: 12.49,
    stock: 12,
    rating: 4.8,
    ratingsCount: 34,
    image: 'https://images.unsplash.com/photo-1527324688151-0e6268899157?w=600&auto=format&fit=crop&q=80',
    isPopular: true
  },
  {
    id: 'p3',
    name: 'Pink Bloom Pure Nectar',
    description: '100% cold-pressed organic dragon fruit juice. Absolutely zero added preservatives, sugar, or water. Pure farm-to-bottle hydration.',
    category: 'Organic Juice',
    price: 6.99,
    stock: 40,
    rating: 4.7,
    ratingsCount: 29,
    image: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=600&auto=format&fit=crop&q=80',
    isPopular: true
  },
  {
    id: 'p4',
    name: 'Artisanal Dragon Fruit Jam',
    description: 'Slow-cooked in small-batch copper kettles using whole farm-grown dragon fruit and organic lemon. Perfect spread for a luxury breakfast.',
    category: 'Dragon Fruit Jam',
    price: 7.49,
    stock: 18,
    rating: 4.9,
    ratingsCount: 22,
    image: 'https://images.unsplash.com/photo-1622484211148-7163102379ca?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'p5',
    name: 'Premium Grafted Sapling (Vietnam Red)',
    description: 'High-yielding, self-pollinating variety sapling, ready for soil planting. Features thick, robust stems with healthy root growth.',
    category: 'Plants & Saplings',
    price: 15.99,
    stock: 15,
    rating: 4.6,
    ratingsCount: 16,
    image: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=600&auto=format&fit=crop&q=80',
    wateringFrequency: 'Every 7-10 days'
  },
  {
    id: 'p6',
    name: 'DragonBio Active Soil Compost',
    description: 'Rich, fully cured organic compost formulated specifically for pitaya cactus roots. High in phosphorous and potash to boost bloom size.',
    category: 'Farm Compost',
    price: 9.99,
    stock: 50,
    rating: 4.8,
    ratingsCount: 19,
    image: 'https://images.unsplash.com/photo-1599599810769-bcde5a160d32?w=600&auto=format&fit=crop&q=80'
  }
];

export const INITIAL_BLOG_POSTS: BlogPost[] = [
  {
    id: 'b1',
    title: 'How to Maximize Pitaya Bloom and Flowering Cycle',
    summary: 'Discover key fertilizer schedules and trellis pruning styles that trigger spectacular dragon fruit blooming.',
    content: `## The Secrets to Dragon Fruit Blooming Success

Dragon fruit (*Hylocereus* species), also known as pitaya, is a nocturnal climbing cactus. To get abundant blooms that set high-grade, heavy fruit, you need to understand the biology of flowering.

### 1. Sunlight Exposure
The climbing pads must have full sun exposure to initiate flower buds. Shaded pads produce 60-70% fewer flowers. Ensure your trellis canopy is pruned to let light reach mature stems.

### 2. Fertilization Schedule
- **Late Winter (Active Growth):** Apply a high-nitrogen manure or compost to grow thick stems.
- **Mid-Spring (Pre-Bloom):** Swap to high-phosphorus and high-potassium fertilizer (like bone meal or organic potash) to stimulate flower bud development.

### 3. Pruning
Prune away the thin, weak hanging tips. Allow only thick, robust pads to drape over the trellis crown. The hanging pads that receive direct vertical sunlight are your primary fruiting stems.

*Pro Tip:* Watch for tiny button-like buds forming on the outer margins of trailing stems. Avoid overwatering once these buttons show!`,
    category: 'Farming Tutorial',
    author: 'Chief Agronomist David Bloom',
    date: '2026-05-18',
    readTime: '4 min read',
    image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&auto=format&fit=crop&q=80',
    likes: 124
  },
  {
    id: 'b2',
    title: 'Organic Pest Control: Dealing with Ants and Scale Bugs',
    summary: 'Protect your vines from sap-sucking scales and symbiotic ant infestations without using chemical toxins.',
    content: `## Natural Pitaya Crop Defense

Vibrant dragon fruit pads contain refreshing sugars that attract sap-sucking pests, especially scale insects and mealybugs. Ants often farm these vectors to harvest honeydew. Here is how of protect your farm organically:

### 1. Organic Neem Oil Sprays
Mix 2 tablespoons of organic cold-pressed neem oil with 1 tablespoon of ecological liquid soap in a gallon of warm water. Spray thoroughly in the late evening (to prevent sun scorching) directly on infected nodes.

### 2. Diatomaceous Earth (DE)
Dust food-grade Diatomaceous Earth around the base of the trellis columns. This forms a mechanical, sharp barrier that deters crawling ants from climbing up to farm scales.

### 3. Companion Planting
Plant marigolds and wild sweet herbs around the perimeter. This recruits predator insects like ladybugs and lacewings, which devour mealybug larvae voraciously.`,
    category: 'Pest Control',
    author: 'Eco-Specialist Lisa Green',
    date: '2026-05-12',
    readTime: '5 min read',
    image: 'https://images.unsplash.com/photo-1516253593875-bd7ba052fbc5?w=600&auto=format&fit=crop&q=80',
    likes: 89
  },
  {
    id: 'b3',
    title: 'Smart Soil & Micro-Drip Irrigation Techniques',
    summary: 'Optimizing water delivery to succulent cactus trunks: learn why waterlogging kills roots and how micro-irrigation saves resources.',
    content: `## Precision Water Architecture for Pitaya

While dragon fruit is a cactus, it originates from tropical rainforests, meaning it requires more frequent watering than typical desert plants. However, poor drainage will trigger root rot within 48 hours.

### 1. The Dynamic Sandy Loam Mix
Vines require porous, highly organic soil. Maintain a ratio of 30% sand, 30% premium compost, 20% agricultural perlite/pumice, and 20% natural topsoil.

### 2. Micro-Drip Settings
Deliver water through low-flow pressure-compensating emitters located 6-8 inches from the central trunk base.
- **Summer cycle:** 1.5 gallons per vine, 3 times weekly.
- **Winter cycle:** 0.5 gallons per vine, once every 10-12 days.

### 3. Monitoring Moisture
Our IoT soil probes trigger automatic alerts when soil humidity drops below 22%. Maintain moisture between 25-40% for active nutrient transport without drowning hair roots.`,
    category: 'Irrigation Methods',
    author: 'Irrigation Engineer Kyle Diaz',
    date: '2026-05-05',
    readTime: '6 min read',
    image: 'https://images.unsplash.com/photo-1463123081488-729f555bc3f1?w=600&auto=format&fit=crop&q=80',
    likes: 67
  }
];

export const INITIAL_WEATHER_DASHBOARD: WeatherData = {
  temp: 28,
  condition: 'Sunny',
  humidity: 64,
  soilMoisture: 32,
  farmHealth: 'Excellent',
  wateringReminders: [
    { time: '06:30 AM', zone: 'South Trellis Area (Red Variety)', duration: '15 mins' },
    { time: '07:00 AM', zone: 'North Greenhouses (Yellow Variety)', duration: '12 mins' },
    { time: '06:00 PM', zone: 'Seedling Propagation Bay', duration: '8 mins' }
  ],
  growthStats: [
    { month: 'Jan', flowering: 10, harvest: 5 },
    { month: 'Feb', flowering: 15, harvest: 8 },
    { month: 'Mar', flowering: 35, harvest: 12 },
    { month: 'Apr', flowering: 55, harvest: 22 },
    { month: 'May', flowering: 85, harvest: 45 },
    { month: 'Jun', flowering: 110, harvest: 78 }
  ]
};

export const TIME_SLOTS = [
  '09:00 AM - 10:30 AM',
  '11:00 AM - 12:30 PM',
  '02:00 PM - 03:30 PM',
  '04:00 PM - 05:30 PM'
];
