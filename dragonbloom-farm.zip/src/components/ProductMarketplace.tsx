import React, { useState, useEffect } from 'react';
import { Search, Heart, ShoppingBag, Mic, Flame, Sparkles, Filter, Check, Star } from 'lucide-react';
import { Product, ProductCategory } from '../types';
import { dbService } from '../dbService';

interface ProductMarketplaceProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
  onViewProduct: (product: Product) => void;
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
}

const CATEGORIES: (ProductCategory | 'All')[] = [
  'All',
  'Fresh Fruits',
  'Organic Juice',
  'Dragon Fruit Jam',
  'Plants & Saplings',
  'Farm Compost'
];

type PreferenceGoal = 'sweet' | 'juice' | 'growing' | 'gift' | 'organic';

export default function ProductMarketplace({
  products,
  onAddToCart,
  onViewProduct,
  setProducts
}: ProductMarketplaceProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory | 'All'>('All');
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [isListening, setIsListening] = useState(false);
  
  // AI Recommendation State
  const [selectedGoal, setSelectedGoal] = useState<PreferenceGoal | null>(null);
  const [recommendedCategories, setRecommendedCategories] = useState<string[]>([]);
  const [isAiLoading, setIsAiLoading] = useState(false);

  useEffect(() => {
    setWishlist(dbService.getWishlist());
  }, []);

  const handleToggleWishlist = (productId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = dbService.toggleWishlist(productId);
    setWishlist(updated);
  };

  // Simulated & Native Mic Voice Search
  const handleVoiceSearch = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      // Graceful fallback simulation
      setIsListening(true);
      setTimeout(() => {
        const triggers = ['Magenta', 'Sapling', 'Juice', 'Compost', 'Jam', 'Golden'];
        const randomQuery = triggers[Math.floor(Math.random() * triggers.length)];
        setSearchTerm(randomQuery);
        setIsListening(false);
      }, 1500);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      const result = event.results[0][0].transcript;
      setSearchTerm(result);
      setIsListening(false);
    };

    recognition.onerror = () => {
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  // AI Recommendation Engine handler
  const handleGetAiRecommendation = async (goal: PreferenceGoal) => {
    setSelectedGoal(goal);
    setIsAiLoading(true);
    
    try {
      const response = await fetch('/api/recommendations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ userPreferences: [goal] })
      });
      const data = await response.json();
      
      if (data.recommended) {
        setRecommendedCategories(data.recommended);
      } else {
        // Safe robust parsing if models replied with standard text strings
        const text = (data.reply || '').toLowerCase();
        const detected: string[] = [];
        if (text.includes('fruit') || text.includes('magenta') || text.includes('solar')) detected.push('Fresh Fruits');
        if (text.includes('juice') || text.includes('pure')) detected.push('Organic Juice');
        if (text.includes('jam') || text.includes('spread')) detected.push('Dragon Fruit Jam');
        if (text.includes('sapling') || text.includes('plant')) detected.push('Plants & Saplings');
        if (text.includes('compost') || text.includes('soil')) detected.push('Farm Compost');
        setRecommendedCategories(detected.length > 0 ? detected : ['Fresh Fruits']);
      }
    } catch (e) {
      // Local deterministic selector
      if (goal === 'growing') {
        setRecommendedCategories(['Plants & Saplings', 'Farm Compost']);
      } else if (goal === 'juice') {
        setRecommendedCategories(['Organic Juice']);
      } else if (goal === 'gift') {
        setRecommendedCategories(['Dragon Fruit Jam', 'Organic Juice']);
      } else {
        setRecommendedCategories(['Fresh Fruits']);
      }
    } finally {
      setIsAiLoading(false);
    }
  };

  // Filtered list
  const filteredProducts = products.filter((product) => {
    const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          product.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="py-6 px-4 max-w-6xl mx-auto space-y-8">
      
      {/* 1. Header with search bar and voice support */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 font-sans">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-[#1B3022] dark:text-[#F3F6F4] tracking-tight">JS Horticulture Marketplace</h1>
          <p className="text-[#1B3022]/70 dark:text-zinc-400 text-xs sm:text-sm font-medium">Organic delicacies and elite farming assets harvested fresh today.</p>
        </div>

        {/* Dynamic Search Box */}
        <div className="relative w-full md:w-80 flex items-center">
          <label htmlFor="product-search-input" className="sr-only">Search products</label>
          <Search className="absolute left-3.5 h-4 w-4 text-zinc-400" />
          <input
            id="product-search-input"
            type="text"
            placeholder="Search organic pits..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-12 py-2 text-xs sm:text-sm bg-[#1B3022]/5 dark:bg-white/5 border-none outline-none focus:ring-2 focus:ring-[#FF4D8D] rounded-full text-[#1B3022] dark:text-[#F3F6F4]"
          />
          <button
            onClick={handleVoiceSearch}
            className={`absolute right-2.5 p-1.5 rounded-full hover:bg-neutral-200 dark:hover:bg-zinc-700 transition-colors cursor-pointer ${
              isListening ? 'bg-[#FF4D8D] text-white animate-ping' : 'text-zinc-400'
            }`}
            title="Voice Search"
          >
            <Mic className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* 2. Premium AI Goal Matcher / Recommendation Panel */}
      <div className="bg-gradient-to-r from-[#1B3022]/10 via-[#FF4D8D]/5 to-transparent border border-[#1B3022]/10 dark:border-white/10 rounded-3xl p-6 relative overflow-hidden font-sans">
        <div className="relative z-10 space-y-4">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg pink-gradient text-white shadow-sm">
              <Sparkles className="h-4 w-4 animate-spin" />
            </div>
            <div>
              <h3 className="text-sm font-black text-[#1B3022] dark:text-[#F3F6F4]">Smart AI Recommendation Engine</h3>
              <p className="text-[11px] text-[#1B3022]/60 dark:text-zinc-400 font-bold">Select your active farming or food goal to reveal matching items:</p>
            </div>
          </div>

          {/* Goal Selector row */}
          <div className="flex flex-wrap gap-2.5">
            {[
              { id: 'sweet', label: 'Indulge in Sweets' },
              { id: 'juice', label: 'Detox Nectar' },
              { id: 'growing', label: 'Grow Backyard Cacti' },
              { id: 'gift', label: 'Farmhouse Gift Box' },
              { id: 'organic', label: 'Soil Health Nutrition' }
            ].map((goal) => (
              <button
                key={goal.id}
                onClick={() => handleGetAiRecommendation(goal.id as PreferenceGoal)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold tracking-wide border transition-all cursor-pointer ${
                  selectedGoal === goal.id
                    ? 'pink-gradient text-white border-none shadow-md'
                    : 'bg-[#FDFBF7] dark:bg-[#0C140F] border-[#1B3022]/10 dark:border-white/10 text-[#1B3022] dark:text-[#F3F6F4] hover:border-[#FF4D8D]'
                }`}
              >
                {goal.label}
              </button>
            ))}
          </div>

          {/* AI Result Feedback */}
          {selectedGoal && (
            <div className="bg-[#ffffff]/60 dark:bg-zinc-900/60 p-3 rounded-2xl flex items-center justify-between text-xs text-zinc-700 dark:text-zinc-300">
              <div className="flex items-center gap-1.5 font-medium">
                {isAiLoading ? (
                  <>
                    <span className="h-2 w-2 rounded-full bg-[#FF4D8D] animate-ping" />
                    Consulting Chief Agronomist AI...
                  </>
                ) : (
                  <>
                    <Check className="h-4 w-4 text-emerald-500" />
                    <span>Agronomist recommendation active: </span>
                    <span className="font-extrabold text-[#2D5A3F] dark:text-[#FF4D8D]">
                      {recommendedCategories.join(' & ')}
                    </span>
                  </>
                )}
              </div>
              {!isAiLoading && (
                <button
                  onClick={() => {
                    setSelectedGoal(null);
                    setRecommendedCategories([]);
                  }}
                  className="text-[10px] font-bold text-red-500 hover:text-red-700 cursor-pointer"
                >
                  Clear filter
                </button>
              )}
            </div>
          )}
        </div>
        
        {/* Subtle visual glow accent */}
        <div className="absolute top-1/2 -right-16 h-36 w-36 bg-[#FF4D8D]/10 rounded-full blur-3xl shadow-2xl" />
      </div>

      {/* 3. Categories Navigation Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-[#1B3022]/10 dark:border-white/10 font-sans">
        <Filter className="h-4 w-4 text-zinc-400 flex-shrink-0" />
        {CATEGORIES.map((cat) => {
          const isCatActive = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 text-xs font-bold rounded-full whitespace-nowrap transition-all duration-300 cursor-pointer ${
                isCatActive
                  ? 'green-gradient text-white shadow-md'
                  : 'bg-[#1B3022]/5 dark:bg-white/5 text-[#1B3022] dark:text-[#F3F6F4] hover:bg-[#1B3022]/10'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* 4. Products grid list */}
      {filteredProducts.length === 0 ? (
        <div className="text-center py-16 space-y-3 font-sans">
          <div className="h-16 w-16 bg-neutral-100 dark:bg-zinc-900 rounded-full flex items-center justify-center mx-auto text-zinc-400">
            <Search className="h-6 w-6" />
          </div>
          <p className="text-zinc-500 dark:text-zinc-400 text-sm font-semibold">No products found matching your active criteria.</p>
          <button
            onClick={() => {
              setSearchTerm('');
              setSelectedCategory('All');
              setSelectedGoal(null);
              setRecommendedCategories([]);
            }}
            className="px-4 py-2 rounded-full green-gradient text-white font-semibold text-xs transition-colors cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 font-sans">
          {filteredProducts.map((p) => {
            const isWished = wishlist.includes(p.id);
            const isRecommended = recommendedCategories.includes(p.category);
            const isLowStock = p.stock > 0 && p.stock <= 15;
            const isOutOfStock = p.stock === 0;

            return (
              <div
                key={p.id}
                onClick={() => onViewProduct(p)}
                className={`group relative rounded-3xl stat-card border overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between cursor-pointer ${
                  isRecommended 
                    ? 'border-[#FF4D8D]/80 ring-2 ring-[#FF4D8D]/15' 
                    : 'border-[#1B3022]/10 dark:border-white/10'
                }`}
              >
                {/* Product Badge Highlights */}
                {isRecommended && (
                  <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 px-2.5 py-1 pink-gradient text-white text-[9px] font-black uppercase tracking-wider rounded-full shadow-lg">
                    <Sparkles className="h-2.5 w-2.5 animate-spin" />
                    AI Pick
                  </div>
                )}

                {/* Wishlist button */}
                <button
                  onClick={(e) => handleToggleWishlist(p.id, e)}
                  className="absolute top-3 right-3 z-10 h-8 w-8 rounded-full bg-white/75 dark:bg-zinc-950/70 backdrop-blur-md flex items-center justify-center transition-colors shadow-sm cursor-pointer"
                  title={isWished ? 'Remove from Wishlist' : 'Add to Wishlist'}
                >
                  <Heart className={`h-4.5 w-4.5 transition-colors ${
                    isWished ? 'fill-red-500 text-red-500' : 'text-zinc-600 dark:text-zinc-300'
                  }`} />
                </button>

                {/* Card Top Block */}
                <div className="relative aspect-[4/3] overflow-hidden bg-neutral-100 dark:bg-zinc-950">
                  <img
                    src={p.image}
                    alt={p.name}
                    className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  {/* Stock Banner Overlay */}
                  {isOutOfStock && (
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center">
                      <span className="px-4 py-1.5 rounded-full bg-red-600 text-white font-black text-xs uppercase tracking-wider">Sold Out</span>
                    </div>
                  )}
                </div>

                {/* Card Content Block */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-1.5">
                    {/* Category Label */}
                    <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-zinc-400">
                      <span>{p.category}</span>
                      {p.rating && (
                        <div className="flex items-center gap-0.5 text-amber-500">
                          <Star className="h-3 w-3 fill-current" />
                          <span>{p.rating}</span>
                        </div>
                      )}
                    </div>
                    
                    {/* Title */}
                    <h3 className="font-extrabold text-[#1B3022] dark:text-[#F3F6F4] text-sm group-hover:text-[#FF4D8D] dark:group-hover:text-pink-300 transition-colors">
                      {p.name}
                    </h3>
                    
                    {/* Description */}
                    <p className="text-[11px] text-[#1B3022]/60 dark:text-zinc-400 line-clamp-2 leading-relaxed">
                      {p.description}
                    </p>
                  </div>

                  {/* Pricing and Buying Controls */}
                  <div className="flex items-center justify-between pt-2">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider block">Price</span>
                      <span className="text-base font-black text-[#FF4D8D] dark:text-pink-400">${p.price}</span>
                    </div>

                    {/* Stock Alert status indicator */}
                    <div className="flex items-center gap-2">
                      {isLowStock && (
                        <span className="text-[10px] font-bold text-amber-500 animate-pulse bg-amber-50 dark:bg-amber-950/20 px-2 py-0.5 rounded-full">Low Stock</span>
                      )}
                      
                      <button
                        id={`add-to-cart-btn-${p.id}`}
                        disabled={isOutOfStock}
                        onClick={(e) => {
                          e.stopPropagation();
                          onAddToCart(p);
                        }}
                        className={`h-9 w-9 flex items-center justify-center rounded-full transition-all shadow-md active:scale-95 cursor-pointer ${
                          isOutOfStock
                            ? 'bg-neutral-100 dark:bg-zinc-800 text-zinc-300 dark:text-zinc-600 shadow-none'
                            : 'green-gradient text-white hover:opacity-95'
                        }`}
                        title="Add to Cart"
                      >
                        <ShoppingBag className="h-4.5 w-4.5" />
                      </button>
                    </div>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
}
