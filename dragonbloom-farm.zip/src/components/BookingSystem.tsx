import React, { useState, useEffect } from 'react';
import { Calendar, Users, Clock, QrCode, ClipboardCheck, Sparkles, Check, X, ShieldCheck, Ticket } from 'lucide-react';
import { Booking, UserProfile } from '../types';
import { dbService } from '../dbService';
import { TIME_SLOTS } from '../mockData';

interface BookingSystemProps {
  user: UserProfile | null;
}

export default function BookingSystem({ user }: BookingSystemProps) {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [activeTab, setActiveTab] = useState<'schedule' | 'my-tickets' | 'admin-approval'>('schedule');

  // Form states
  const [visitorName, setVisitorName] = useState(user?.displayName || '');
  const [visitorEmail, setVisitorEmail] = useState(user?.email || '');
  const [bookingDate, setBookingDate] = useState('');
  const [selectedSlot, setSelectedSlot] = useState(TIME_SLOTS[0]);
  const [numberOfVisitors, setNumberOfVisitors] = useState(2);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState<Booking | null>(null);

  // Load bookings
  const loadBookings = () => {
    dbService.getBookings().then((list) => {
      // If Customer, filter or show all
      if (user?.role === 'Customer') {
        setBookings(list.filter((b) => b.userId === user.uid));
      } else {
        setBookings(list);
      }
    });
  };

  useEffect(() => {
    loadBookings();
    if (user?.role === 'Admin' || user?.role === 'Farm Worker') {
      setActiveTab('admin-approval');
    }
  }, [user]);

  // Calculate current slot capacities for visitor limit management
  const getSlotCapacityUsed = (date: string, slot: string) => {
    return bookings
      .filter((b) => b.date === date && b.timeSlot === slot && b.status !== 'rejected')
      .reduce((sum, b) => sum + b.visitorsCount, 0);
  };

  const handleCreateBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      alert("Please log in to book a farm tour.");
      return;
    }

    if (!bookingDate) {
      alert("Please select a valid date.");
      return;
    }

    // Capacity checks (Visitor Limit Management)
    const activeCapacity = getSlotCapacityUsed(bookingDate, selectedSlot);
    const capacityCap = 25; // 25 max people per slot
    if (activeCapacity + numberOfVisitors > capacityCap) {
      alert(`Capacity Exceeded! The selected slot has already filled ${activeCapacity}/${capacityCap} seats. Please decrease your visitors or choose another slot.`);
      return;
    }

    setIsSubmitting(true);
    const bookingPayload = {
      userId: user.uid,
      userName: visitorName,
      userEmail: visitorEmail,
      date: bookingDate,
      timeSlot: selectedSlot,
      visitorsCount: numberOfVisitors,
    };

    try {
      const created = await dbService.createBooking(bookingPayload);
      setSubmitSuccess(created);
      setBookings((prev) => [created, ...prev]);
      setVisitorName(user.displayName);
      setBookingDate('');
      // Switch view
      setTimeout(() => {
        setSubmitSuccess(null);
        setActiveTab('my-tickets');
      }, 4000);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Admin Approval triggers
  const handleUpdateStatus = async (id: string, newStatus: 'approved' | 'rejected') => {
    try {
      await dbService.updateBookingStatus(id, newStatus);
      // Reload from local storage repository
      loadBookings();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="py-6 px-4 max-w-4xl mx-auto space-y-6">
      
      {/* Tab Navigation header */}
      <div className="flex items-center gap-2 border-b border-[#1B3022]/10 dark:border-white/10 pb-2.5 overflow-x-auto scrollbar-none font-sans">
        <button
          onClick={() => setActiveTab('schedule')}
          className={`px-4 py-2 text-xs font-bold rounded-full transition-all cursor-pointer ${
            activeTab === 'schedule'
              ? 'pink-gradient text-white shadow-md'
              : 'text-zinc-650 dark:text-zinc-400 hover:bg-neutral-50 dark:hover:bg-zinc-800'
          }`}
        >
          Plan Tour Visit
        </button>
        <button
          onClick={() => setActiveTab('my-tickets')}
          className={`px-4 py-2 text-xs font-bold rounded-full transition-all cursor-pointer ${
            activeTab === 'my-tickets'
              ? 'pink-gradient text-white shadow-md'
              : 'text-zinc-650 dark:text-zinc-400 hover:bg-neutral-50 dark:hover:bg-zinc-800'
          }`}
        >
          My Tickets ({bookings.filter(b => b.userId === user?.uid).length})
        </button>

        {/* Admin and Operator access tab */}
        {(user?.role === 'Admin' || user?.role === 'Farm Worker') && (
          <button
            onClick={() => setActiveTab('admin-approval')}
            className={`px-4 py-2 text-xs font-bold rounded-full transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'admin-approval'
                ? 'green-gradient text-white shadow-md'
                : 'text-[#2D5A3F] dark:text-[#FF4D8D] bg-[#2D5A3F]/10 dark:bg-[#2D5A3F]/30 hover:bg-[#2D5A3F]/15'
            }`}
          >
            <ClipboardCheck className="h-4 w-4" />
            Manage Bookings Panel
          </button>
        )}
      </div>

      {/* ---------------------------------------------------- */}
      {/* SUB-TAB 1: BOOKING FORM LIST */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'schedule' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Scheduling Guidelines */}
          <div className="bg-gradient-to-tr from-[#2D5A3F]/10 via-transparent to-transparent border border-[#1B3022]/10 dark:border-white/10 rounded-3xl p-6 h-fit space-y-4 font-sans">
            <span className="text-[10px] font-extrabold tracking-widest text-[#2D5A3F] dark:text-[#FF4D8D] uppercase">Farm Guidelines</span>
            <h3 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100">Pitaya Field Tours</h3>
            <p className="text-zinc-500 dark:text-zinc-400 text-xs leading-relaxed font-semibold">
              Explore the sprawling trellis orchards of JS Horticulture, learn about our automated IoT micro-irrigation lines, and pick fresh organic dragon fruits with your family.
            </p>
            
            <div className="space-y-3.5 pt-3 text-xs text-zinc-600 dark:text-zinc-400 font-extrabold">
              <div className="flex items-center gap-2">
                <Users className="h-4.5 w-4.5 text-[#2D5A3F]" />
                <span>Limit 25 guests per session</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4.5 w-4.5 text-[#2D5A3F]" />
                <span>Runs hourly, 9:00 AM - 5:30 PM</span>
              </div>
              <div className="flex items-center gap-2">
                <Ticket className="h-4.5 w-4.5 text-[#2D5A3F]" />
                <span>QR Confirmation instantly on Approval</span>
              </div>
            </div>
          </div>

          {/* Form container */}
          <div className="md:col-span-2 bg-[#ffffff] dark:bg-[#111e16] border border-[#1B3022]/10 dark:border-white/10 p-6 rounded-3xl relative overflow-hidden font-sans">
            <h3 className="font-extrabold text-sm text-[#1B3022] dark:text-white mb-4">Select Schedule Slots</h3>

            {submitSuccess ? (
              <div className="py-12 text-center space-y-4">
                <div className="h-16 w-16 bg-[#2D5A3F]/10 dark:bg-[#2D5A3F]/30 rounded-full flex items-center justify-center mx-auto text-emerald-600">
                  <Check className="h-8 w-8 scale-110" />
                </div>
                <div>
                  <h4 className="font-black text-sm text-zinc-900 dark:text-zinc-100">Tours Ticket Reserved!</h4>
                  <p className="text-xs text-zinc-500 mt-1">Booking reference <span className="font-mono text-[#FF4D8D] font-bold">{submitSuccess.id}</span> generated. Switching tabs...</p>
                </div>
              </div>
            ) : (
              <form onSubmit={handleCreateBooking} className="space-y-4 text-xs font-semibold">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label htmlFor="booking-name" className="font-bold text-zinc-450 uppercase tracking-widest text-[9px]">Visitor Name</label>
                    <input
                      id="booking-name"
                      required
                      type="text"
                      value={visitorName}
                      onChange={(e) => setVisitorName(e.target.value)}
                      placeholder="Kumar Soumyanarayan"
                      className="w-full p-2.5 bg-[#1B3022]/5 dark:bg-white/5 border-none outline-none focus:ring-2 focus:ring-[#FF4D8D] rounded-lg text-zinc-800 dark:text-zinc-200"
                    />
                  </div>

                  <div className="space-y-1">
                    <label htmlFor="booking-email" className="font-bold text-zinc-450 uppercase tracking-widest text-[9px]">Email Address</label>
                    <input
                      id="booking-email"
                      required
                      type="email"
                      value={visitorEmail}
                      onChange={(e) => setVisitorEmail(e.target.value)}
                      placeholder="visitor@jshorticulture.com"
                      className="w-full p-2.5 bg-[#1B3022]/5 dark:bg-white/5 border-none outline-none focus:ring-2 focus:ring-[#FF4D8D] rounded-lg text-zinc-800 dark:text-zinc-200"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label htmlFor="booking-date" className="font-bold text-zinc-455 uppercase tracking-widest text-[9px]">Tour Date</label>
                    <input
                      id="booking-date"
                      required
                      type="date"
                      value={bookingDate}
                      onChange={(e) => setBookingDate(e.target.value)}
                      min={new Date().toISOString().split('T')[0]} // Block prior dates
                      className="w-full p-2.5 bg-[#1B3022]/5 dark:bg-white/5 border-none outline-none focus:ring-2 focus:ring-[#FF4D8D] rounded-lg text-zinc-800 dark:text-zinc-200"
                    />
                  </div>

                  <div className="space-y-1">
                    <label htmlFor="booking-slot" className="font-bold text-zinc-455 uppercase tracking-widest text-[9px]">Preferred Time Slots</label>
                    <select
                      id="booking-slot"
                      value={selectedSlot}
                      onChange={(e) => setSelectedSlot(e.target.value)}
                      className="w-full p-2.5 bg-[#1B3022]/5 dark:bg-white/5 border-none outline-none focus:ring-2 focus:ring-[#FF4D8D] rounded-lg text-zinc-800 dark:text-zinc-200 font-bold"
                    >
                      {TIME_SLOTS.map(st => (
                        <option key={st} value={st}>{st}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label htmlFor="booking-visitors" className="font-bold text-zinc-450 uppercase tracking-widest text-[9px]">Number of Guests</label>
                    {bookingDate && (
                      <span className="text-[10px] font-bold text-[#2D5A3F] dark:text-[#FF4D8D]">
                        Slot Capacity Used: {getSlotCapacityUsed(bookingDate, selectedSlot)}/25
                      </span>
                    )}
                  </div>
                  <input
                    id="booking-visitors"
                    required
                    type="number"
                    min="1"
                    max="10"
                    value={numberOfVisitors}
                    onChange={(e) => setNumberOfVisitors(Number(e.target.value))}
                    className="w-full p-2.5 bg-[#1B3022]/5 dark:bg-white/5 border-none outline-none focus:ring-2 focus:ring-[#FF4D8D] rounded-lg text-zinc-800 dark:text-zinc-200 font-black text-sm"
                  />
                  <p className="text-[10px] text-zinc-400">Reservations require at least 1 person and max 10 people per booking.</p>
                </div>

                <button
                  id="submit-booking-btn"
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 mt-2 rounded-full pink-gradient text-white font-bold text-xs tracking-wide shadow-lg flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isSubmitting ? (
                    <>
                      <span className="h-3.5 w-3.5 rounded-full border-2 border-white border-t-transparent animate-spin" />
                      Saving secure reservation...
                    </>
                  ) : (
                    <>
                      Confirm Tour Reservation Slot
                    </>
                  )}
                </button>

              </form>
            )}

          </div>

        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* SUB-TAB 2: MY TICKETS WITH SCAN QR CODE */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'my-tickets' && (
        <div className="space-y-4 font-sans">
          {bookings.filter(b => b.userId === user?.uid).length === 0 ? (
            <div className="text-center py-16 bg-[#ffffff] dark:bg-[#111e16] border border-[#1B3022]/10 dark:border-white/10 rounded-3xl space-y-4 p-6 shadow-sm">
              <div className="h-14 w-14 bg-[#1B3022]/5 dark:bg-white/5 rounded-full flex items-center justify-center mx-auto text-[#FF4D8D]">
                <Ticket className="h-6 w-6" />
              </div>
              <p className="text-[#1B3022]/70 dark:text-zinc-300 text-xs font-bold font-sans">You have reserved no prior visits.</p>
              <button
                onClick={() => setActiveTab('schedule')}
                className="px-5 py-2 rounded-full pink-gradient text-white font-bold text-xs cursor-pointer"
              >
                Plan Farmhouse Tour Now
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-sans">
              {bookings
                .filter(b => b.userId === user?.uid)
                .map((bk) => (
                  <div
                    key={bk.id}
                    className="bg-[#ffffff] dark:bg-[#111e16] border border-[#1B3022]/10 dark:border-white/10 p-5 rounded-3xl shadow-sm space-y-4 hover:shadow-md transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between border-b border-[#1B3022]/10 dark:border-white/10 pb-2.5">
                        <div className="flex items-center gap-1">
                          <Ticket className="h-4 w-4 text-[#FF4D8D] animate-bounce" />
                          <span className="font-extrabold text-xs text-[#1B3022] dark:text-[#F3F6F4]">{bk.id}</span>
                        </div>
                        
                        {/* Status Label badge */}
                        <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                          bk.status === 'approved'
                            ? 'bg-[#2D5A3F]/10 text-[#2D5A3F] dark:text-[#FF4D8D]'
                            : bk.status === 'rejected'
                            ? 'bg-red-50 text-red-550 dark:bg-red-955/20 dark:text-red-405'
                            : 'bg-amber-50 text-amber-500'
                        }`}>
                          {bk.status}
                        </span>
                      </div>

                      {/* Details specs */}
                      <div className="space-y-2 text-xs text-[#1B3022]/80 dark:text-zinc-400 py-3 font-semibold">
                        <div className="flex items-center gap-1.5">
                          <Calendar className="h-3.5 w-3.5 text-zinc-400" />
                          <span>Date: <span className="font-extrabold text-[#1B3022] dark:text-[#F3F6F4]">{new Date(bk.date).toLocaleDateString()}</span></span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Clock className="h-3.5 w-3.5 text-zinc-400" />
                          <span>Slot: <span className="font-extrabold text-[#1B3022] dark:text-[#F3F6F4]">{bk.timeSlot}</span></span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Users className="h-3.5 w-3.5 text-zinc-400" />
                          <span>Visitors: <span className="font-extrabold text-[#1B3022] dark:text-[#F3F6F4]">{bk.visitorsCount} Guests</span></span>
                        </div>
                      </div>
                    </div>

                    {/* QR Code section */}
                    {bk.status === 'approved' ? (
                      <div className="pt-3 border-t border-dashed border-[#1B3022]/10 dark:border-white/10 flex items-center justify-between gap-4">
                        <div className="bg-[#1B3022]/5 dark:bg-zinc-950 p-2 rounded-2xl border border-[#1B3022]/10 dark:border-white/10 max-w-[80px]">
                          {/* Aesthetic vector representation for QR Code */}
                          <QrCode className="h-14 w-14 text-zinc-700 dark:text-zinc-300" />
                        </div>
                        <div className="text-[10px] text-zinc-550 dark:text-zinc-400 leading-relaxed flex-1 font-semibold">
                          <span className="font-extrabold text-[#2D5A3F] dark:text-[#FF4D8D] block uppercase">Gate Pass Active</span>
                          Present this ticket QR code inside the welcome farmhouse lounge for verified entry.
                        </div>
                      </div>
                    ) : bk.status === 'rejected' ? (
                      <div className="pt-3 border-t border-[#1B3022]/10 dark:border-white/10 text-[10px] text-red-500 font-semibold leading-relaxed">
                        Reservation declined. Capacity limits exceeded. Please contact farm support to select a fresh date.
                      </div>
                    ) : (
                      <div className="pt-3 border-t border-[#1B3022]/10 dark:border-white/10 text-[10px] text-amber-500 font-semibold flex items-center gap-1.5">
                        <span className="h-2 w-2 rounded-full bg-amber-400 animate-ping" />
                        Awaiting operator clearance... Verified ticket generates once approved.
                      </div>
                    )}

                  </div>
                ))}
            </div>
          )}
        </div>
      )}

      {activeTab === 'admin-approval' && (user?.role === 'Admin' || user?.role === 'Farm Worker') && (
        <div className="space-y-4 font-sans">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-[#1B3022] dark:text-white">Farmside Reservations Ledger</h3>
            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">{bookings.length} reservations logged</span>
          </div>

          {bookings.length === 0 ? (
            <div className="text-center py-12 p-6 bg-[#ffffff] dark:bg-[#111e16] border border-[#1B3022]/10 dark:border-white/10 rounded-3xl">
              <p className="text-zinc-400 text-xs font-semibold">No customer tour records located in system.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {bookings.map((b) => (
                <div
                  key={b.id}
                  className="bg-[#ffffff] dark:bg-[#111e16] border border-[#1B3022]/10 dark:border-white/10 p-4 rounded-3xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shadow-sm"
                >
                  <div className="space-y-1 text-xs font-semibold">
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-[#1B3022] dark:text-white">{b.id}</span>
                      <span className="text-[#1B3022]/70 dark:text-zinc-400 font-bold">by {b.userName} ({b.userEmail})</span>
                      <span className={`px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider ${
                        b.status === 'approved'
                          ? 'bg-[#2D5A3F]/10 text-[#2D5A3F]'
                          : b.status === 'rejected'
                          ? 'bg-red-50 text-red-500'
                          : 'bg-amber-50 text-amber-500'
                      }`}>
                        {b.status}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-4 text-[11px] text-zinc-500 pt-1 font-medium">
                      <span>Date: <span className="font-bold">{new Date(b.date).toLocaleDateString()}</span></span>
                      <span>Slot: <span className="font-bold">{b.timeSlot}</span></span>
                      <span>Visitors: <span className="font-bold">{b.visitorsCount} Guests</span></span>
                    </div>
                  </div>

                  {/* Approve Reject control triggers */}
                  {b.status === 'pending' ? (
                    <div className="flex items-center gap-2 w-full sm:w-auto font-sans">
                      <button
                        onClick={() => handleUpdateStatus(b.id, 'approved')}
                        className="flex-1 sm:flex-initial px-3 py-1.5 rounded-xl green-gradient text-white font-bold text-[10px] flex items-center justify-center gap-1 shadow-sm cursor-pointer hover:opacity-95"
                      >
                        <Check className="h-3.5 w-3.5" />
                        Approve
                      </button>
                      <button
                        onClick={() => handleUpdateStatus(b.id, 'rejected')}
                        className="flex-1 sm:flex-initial px-3 py-1.5 rounded-xl border border-[#FF4D8D]/20 hover:bg-[#FF4D8D]/10 text-[#FF4D8D] font-bold text-[10px] flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <X className="h-3.5 w-3.5" />
                        Decline
                      </button>
                    </div>
                  ) : (
                    <div className="text-[10px] font-bold text-zinc-400 self-center">
                      Resolved as <span className="uppercase">{b.status}</span>
                    </div>
                  )}

                </div>
              ))}
            </div>
          )}
        </div>
      )}

    </div>
  );
}
