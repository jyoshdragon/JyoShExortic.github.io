import { LayoutDashboard, ShoppingCart, CalendarRange, BookOpen, Sparkles, User, LogOut, Sun, Moon, ShoppingBag } from 'lucide-react';
import { UserRole, UserProfile } from '../types';

interface FloatingNavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  cartCount: number;
  user: UserProfile | null;
  onLogout: () => void;
  onSwitchRole: (role: UserRole) => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
}

export default function FloatingNavbar({
  currentTab,
  setCurrentTab,
  cartCount,
  user,
  onLogout,
  onSwitchRole,
  darkMode,
  setDarkMode
}: FloatingNavbarProps) {
  return (
    <nav className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 w-[95%] max-w-4xl bg-[#FDFBF7]/85 dark:bg-[#0C140F]/85 backdrop-blur-lg border border-[#1B3022]/10 dark:border-white/10 rounded-full py-2.5 px-4 shadow-xl transition-all duration-300">
      <div className="flex items-center justify-between gap-1 md:gap-4 font-sans">
        
        {/* Farm Brand Header */}
        <div className="hidden md:flex items-center gap-2 pl-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-full pink-gradient text-white font-bold relative overflow-hidden">
            <span className="relative z-10 text-[10px]">JS</span>
          </div>
          <span className="serif-font text-base font-bold tracking-tight text-[#1B3022] dark:text-[#F3F6F4]">
            JS Horticulture<span className="text-[#FF4D8D]">.</span>
          </span>
        </div>

        {/* Core Navigation Items */}
        <div className="flex items-center justify-center flex-1 gap-1 sm:gap-2">
          {[
            { id: 'home', label: 'Home', icon: Sparkles },
            { id: 'shop', label: 'Shop', icon: ShoppingBag },
            { id: 'booking', label: 'Tours', icon: CalendarRange },
            { id: 'learn', label: 'Hub', icon: BookOpen },
            { id: 'dashboard', label: 'Farming', icon: LayoutDashboard },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = currentTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`nav-tab-${tab.id}`}
                onClick={() => setCurrentTab(tab.id)}
                className={`relative flex flex-col md:flex-row items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] md:text-xs font-bold tracking-wide transition-all duration-300 select-none cursor-pointer ${
                  isActive
                    ? 'green-gradient text-white shadow-md active:scale-95'
                    : 'text-[#1B3022]/70 dark:text-[#F3F6F4]/70 hover:bg-[#1B3022]/5 dark:hover:bg-white/5'
                }`}
              >
                <Icon className="h-4.5 w-4.5" />
                <span className="hidden sm:inline">{tab.label}</span>
                {isActive && (
                  <span className="absolute -top-1 -right-1 flex h-2 w-2 rounded-full bg-[#FF4D8D] animate-ping" />
                )}
              </button>
            );
          })}
        </div>

        {/* Action Controls & Role Swapper */}
        <div className="flex items-center gap-1 sm:gap-2 pr-1">
          
          {/* Cart Icon Link */}
          <button
            id="nav-cart-btn"
            onClick={() => setCurrentTab('cart')}
            className={`relative p-2 rounded-full text-[#1B3022] dark:text-[#F3F6F4] hover:bg-[#1B3022]/5 dark:hover:bg-white/5 transition-all cursor-pointer ${
              currentTab === 'cart' ? 'bg-[#FF4D8D]/10 dark:bg-[#FF4D8D]/20 text-[#FF4D8D]' : ''
            }`}
          >
            <ShoppingCart className="h-4.5 w-4.5" />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 flex h-4.5 w-4.5 items-center justify-center rounded-full pink-gradient text-[9px] font-extrabold text-white ring-2 ring-[#FDFBF7] dark:ring-[#0C140F]">
                {cartCount}
              </span>
            )}
          </button>

          {/* Theme Button */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="p-2 rounded-full text-zinc-600 dark:text-zinc-300 hover:bg-[#1B3022]/5 dark:hover:bg-white/5 transition-all cursor-pointer"
            aria-label="Toggle Theme"
          >
            {darkMode ? <Sun className="h-4.5 w-4.5 text-amber-400" /> : <Moon className="h-4.5 w-4.5 text-[#1B3022]" />}
          </button>

          {/* Quick Role Toggle Bar for Demo Context */}
          {user && (
            <div className="relative group">
              <button className="flex items-center gap-1 pl-1.5 pr-2 py-1 rounded-full bg-[#1B3022]/5 dark:bg-white/5 text-[#1B3022] dark:text-[#F3F6F4] border border-[#1B3022]/10 dark:border-white/10 text-[10px] sm:text-xs font-semibold cursor-pointer">
                <User className="h-3.5 w-3.5 text-[#2D5A3F] dark:text-[#FF4D8D]" />
                <span className="hidden md:inline truncate max-w-[65px]">{user.displayName}</span>
                <span className="px-1.5 py-0.5 rounded-full bg-[#FF4D8D]/10 text-[#FF4D8D] dark:bg-[#FF4D8D]/20 dark:text-[#FF4D8D] text-[9.5px] scale-90 font-extrabold">
                  {user.role}
                </span>
              </button>
              
              {/* Dropdown Menu for Immediate Role Switching */}
              <div className="absolute right-0 bottom-12 mb-1 w-44 bg-[#FDFBF7] dark:bg-[#0C140F] border border-[#1B3022]/10 dark:border-white/10 rounded-xl p-2.5 shadow-xl scale-0 group-hover:scale-100 origin-bottom-right transition-all duration-200">
                <p className="text-[9px] font-bold text-[#1B3022]/50 dark:text-[#F3F6F4]/50 mb-2 uppercase tracking-wide px-1">Explore App Roles:</p>
                <div className="flex flex-col gap-1">
                  {(['Customer', 'Farm Worker', 'Admin'] as UserRole[]).map((role) => (
                    <button
                      key={role}
                      onClick={() => onSwitchRole(role)}
                      className={`w-full text-left px-2 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                        user.role === role
                          ? 'emerald-active-gradient bg-[#2D5A3F] text-white font-black px-2'
                          : 'text-[#1B3022] dark:text-[#F3F6F4] hover:bg-[#1B3022]/5 dark:hover:bg-white/5'
                      }`}
                    >
                      {role} Workspace
                    </button>
                  ))}
                  
                  {user.role === 'Admin' && (
                    <button
                      onClick={() => setCurrentTab('admin')}
                      className={`w-full text-left mt-1.5 pt-1.5 border-t border-neutral-100 dark:border-zinc-800 text-xs font-semibold flex items-center gap-1.5 ${
                        currentTab === 'admin'
                          ? 'text-pink-600'
                          : 'text-zinc-800 dark:text-zinc-200 hover:text-pink-500'
                      }`}
                    >
                      <LayoutDashboard className="h-3.5 w-3.5" />
                      Admin Control
                    </button>
                  )}

                  <button
                    onClick={onLogout}
                    className="w-full text-left mt-1 pt-1 border-t border-neutral-100 dark:border-zinc-800 text-xs text-red-500 font-medium flex items-center gap-1.5 hover:bg-red-50/50 dark:hover:bg-red-950/20 px-2 py-1 rounded-lg"
                  >
                    <LogOut className="h-3.5 w-3.5" />
                    Reset Account
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </nav>
  );
}
