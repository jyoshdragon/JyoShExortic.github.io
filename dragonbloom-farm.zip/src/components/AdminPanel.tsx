import React, { useState, useEffect } from 'react';
import { LayoutGrid, ClipboardList, BellRing, Users, Sparkles, PlusCircle, Trash, Check, TrendingDown } from 'lucide-react';
import { Product, Order, UserProfile, ProductCategory } from '../types';
import { dbService } from '../dbService';

interface AdminPanelProps {
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  onPushBroadcast: (msg: string) => void;
  user: UserProfile | null;
}

const CATEGORIES: ProductCategory[] = [
  'Fresh Fruits',
  'Organic Juice',
  'Dragon Fruit Jam',
  'Plants & Saplings',
  'Farm Compost'
];

export default function AdminPanel({
  products,
  setProducts,
  onPushBroadcast,
  user
}: AdminPanelProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeTab, setActiveTab] = useState<'inventory' | 'orders' | 'push' | 'users'>('inventory');
  
  // New Product states
  const [newProductName, setNewProductName] = useState('');
  const [newProductCategory, setNewProductCategory] = useState<ProductCategory>('Fresh Fruits');
  const [newProductDesc, setNewProductDesc] = useState('');
  const [newProductPrice, setNewProductPrice] = useState(4.99);
  const [newProductStock, setNewProductStock] = useState(20);
  const [newProductImage, setNewProductImage] = useState('https://images.unsplash.com/photo-1527324688151-0e6268899157?w=300');

  // Push notification states
  const [broadcastMessage, setBroadcastMessage] = useState('');

  // Loaded users mock
  const [systemUsers, setSystemUsers] = useState<UserProfile[]>([]);

  const loadData = () => {
    dbService.getOrders().then(setOrders);
    dbService.getSystemUsers().then(setSystemUsers);
  };

  useEffect(() => {
    loadData();
  }, [products]);

  // Product Add handler
  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProductName.trim()) return;

    const payload = {
      name: newProductName.trim(),
      category: newProductCategory,
      description: newProductDesc,
      price: newProductPrice,
      stock: newProductStock,
      image: newProductImage,
      rating: 5,
      ratingsCount: 1
    };

    try {
      const created = await dbService.createProduct(payload);
      setProducts(prev => [created, ...prev]);
      
      // Reset forms
      setNewProductName('');
      setNewProductDesc('');
      setNewProductPrice(4.99);
      setNewProductStock(25);
    } catch (err) {
      console.error(err);
    }
  };

  // Product stock increment handler
  const handleQuickAddStock = async (productId: string, delta: number) => {
    try {
      const updated = await dbService.updateProductStock(productId, delta);
      setProducts(prev => prev.map(p => p.id === productId ? updated : p));
    } catch (err) {
      console.error(err);
    }
  };

  // Order Fulfilled status increment
  const handleCompleteOrder = async (orderId: string) => {
    try {
      await dbService.updateOrderStatus(orderId, 'delivered');
      loadData();
    } catch (err) {
      console.error(err);
    }
  };

  // Push broadcast trigger
  const handleTriggerPush = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastMessage.trim()) return;
    onPushBroadcast(broadcastMessage.trim());
    setBroadcastMessage('');
  };

  if (!user || (user.role !== 'Admin' && user.role !== 'Farm Worker')) {
    return (
      <div className="py-12 text-center text-zinc-400">
        <TrendingDown className="h-10 w-10 mx-auto text-red-500 mb-2 animate-bounce" />
        <p className="text-sm font-bold">Workspace Access Denied. Toggle Admin Role in navbar.</p>
      </div>
    );
  }

  return (
    <div className="py-6 px-4 max-w-4xl mx-auto space-y-6">
      
      {/* Title display */}
      <div className="flex items-center justify-between border-b border-neutral-100 dark:border-zinc-800 pb-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-neutral-900 dark:text-zinc-100 tracking-tight">Farm Executive Control</h1>
          <p className="text-zinc-500 dark:text-zinc-400 text-xs sm:text-sm font-medium">Estate inventory oversight, order fulfilling, and push triggers.</p>
        </div>
        <span className="px-3 py-1 bg-pink-100 text-pink-600 dark:bg-pink-900/30 dark:text-pink-400 text-xs uppercase font-extrabold rounded-full">
          {user.role} Hub
        </span>
      </div>

      {/* Segment Select buttons */}
      <div className="flex flex-wrap items-center gap-2 border-b border-neutral-200/50 dark:border-zinc-800 pb-2.5 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveTab('inventory')}
          className={`px-4 py-2 text-xs font-bold rounded-full transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'inventory' ? 'bg-emerald-600 text-white shadow-sm' : 'text-zinc-600 dark:text-zinc-400'
          }`}
        >
          <LayoutGrid className="h-4 w-4" />
          Catalog Catalog ({products.length})
        </button>
        <button
          onClick={() => setActiveTab('orders')}
          className={`px-4 py-2 text-xs font-bold rounded-full transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'orders' ? 'bg-emerald-600 text-white shadow-sm' : 'text-zinc-600 dark:text-zinc-400'
          }`}
        >
          <ClipboardList className="h-4 w-4" />
          Inbound Escrows ({orders.length})
        </button>
        <button
          onClick={() => setActiveTab('push')}
          className={`px-4 py-2 text-xs font-bold rounded-full transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'push' ? 'bg-emerald-600 text-white shadow-sm' : 'text-zinc-600 dark:text-zinc-400'
          }`}
        >
          <BellRing className="h-4 w-4" />
          Push Broadcaster
        </button>
        <button
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2 text-xs font-bold rounded-full transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'users' ? 'bg-emerald-600 text-white shadow-sm' : 'text-zinc-600 dark:text-zinc-400'
          }`}
        >
          <Users className="h-4 w-4" />
          Users Ledger ({systemUsers.length})
        </button>
      </div>

      {/* ---------------------------------------------------- */}
      {/* SECTION 1: INVENTORY MANAGEMENT */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'inventory' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Add Product forms */}
          <div className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800/60 p-5 rounded-3xl h-fit space-y-4">
            <div className="flex items-center gap-2">
              <PlusCircle className="h-4.5 w-4.5 text-pink-500" />
              <h3 className="font-extrabold text-xs text-neutral-800 dark:text-zinc-100 uppercase tracking-wider">Load New Product</h3>
            </div>

            <form onSubmit={handleAddProduct} className="space-y-3.5 text-xs">
              <div className="space-y-1">
                <label htmlFor="new-product-name" className="font-bold text-zinc-400">Name</label>
                <input
                  id="new-product-name"
                  required
                  type="text"
                  value={newProductName}
                  onChange={(e) => setNewProductName(e.target.value)}
                  placeholder="Royal Magenta King"
                  className="w-full p-2 bg-neutral-50 dark:bg-zinc-800 border-none outline-none rounded"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label htmlFor="new-product-category" className="font-bold text-zinc-400">Category</label>
                  <select
                    id="new-product-category"
                    value={newProductCategory}
                    onChange={(e) => setNewProductCategory(e.target.value as ProductCategory)}
                    className="w-full p-2 bg-neutral-50 dark:bg-zinc-800 border-none outline-none rounded text-[11px]"
                  >
                    {CATEGORIES.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label htmlFor="new-product-price" className="font-bold text-zinc-400">Price ($)</label>
                  <input
                    id="new-product-price"
                    required
                    type="number"
                    step="0.01"
                    value={newProductPrice}
                    onChange={(e) => setNewProductPrice(Number(e.target.value))}
                    className="w-full p-2 bg-neutral-50 dark:bg-zinc-800 border-none outline-none rounded"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label htmlFor="new-product-stock" className="font-bold text-zinc-400">Stock</label>
                  <input
                    id="new-product-stock"
                    required
                    type="number"
                    value={newProductStock}
                    onChange={(e) => setNewProductStock(Number(e.target.value))}
                    className="w-full p-2 bg-neutral-50 dark:bg-zinc-800 border-none outline-none rounded"
                  />
                </div>

                <div className="space-y-1">
                  <label htmlFor="new-product-image" className="font-bold text-zinc-400">Image Tag</label>
                  <select
                    id="new-product-image"
                    value={newProductImage}
                    onChange={(e) => setNewProductImage(e.target.value)}
                    className="w-full p-2 bg-neutral-50 dark:bg-zinc-800 border-none outline-none rounded text-[11px]"
                  >
                    <option value="https://images.unsplash.com/photo-1527324688151-0e6268899157?w=450">Magenta Fruit</option>
                    <option value="https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=450">Sapling Vines</option>
                    <option value="https://images.unsplash.com/photo-1584589167171-541ce45f1eea?w=450">Compost Soil</option>
                    <option value="https://images.unsplash.com/photo-1463123081488-729f555bc3f1?w=450">Organic Nectar</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label htmlFor="new-product-description" className="font-bold text-zinc-400">Description</label>
                <textarea
                  id="new-product-description"
                  required
                  rows={2}
                  value={newProductDesc}
                  onChange={(e) => setNewProductDesc(e.target.value)}
                  placeholder="Sourced from potassium-enriched volcanic soil sectors..."
                  className="w-full p-2 bg-neutral-50 dark:bg-zinc-800 border-none outline-none rounded resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-pink-500 hover:bg-pink-600 text-white font-bold text-xs tracking-wide cursor-pointer flex items-center justify-center gap-1.5"
              >
                Create Catalog Entry
              </button>
            </form>
          </div>

          {/* Core Inventory items list tabular layout */}
          <div className="md:col-span-2 space-y-3 max-h-[500px] overflow-y-auto pr-1 scrollbar-none">
            {products.map((p) => {
              const isLow = p.stock <= 15;
              return (
                <div
                  key={p.id}
                  className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800/80 p-3.5 rounded-3xl flex justify-between items-center gap-4 text-xs shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={p.image}
                      alt={p.name}
                      className="h-10 w-10 object-cover rounded-xl bg-neutral-100 dark:bg-zinc-950"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <h4 className="font-extrabold text-zinc-900 dark:text-zinc-100">{p.name}</h4>
                      <div className="flex items-center gap-3 text-[10px] text-zinc-400 font-bold pt-0.5 uppercase tracking-wider">
                        <span>{p.category}</span>
                        <span className="text-rose-500">${p.price}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Stock modifier controls */}
                    <div className="flex items-center gap-1.5 p-1 rounded-full bg-neutral-50 dark:bg-zinc-950/60 border border-neutral-100">
                      <button
                        onClick={() => handleQuickAddStock(p.id, -5)}
                        className="px-1.5 py-0.5 rounded-full text-[9px] font-bold text-zinc-500 hover:text-red-500 cursor-pointer"
                        title="Reduce stock by 5"
                      >
                        -5
                      </button>
                      <span className={`text-[10px] font-mono font-black min-w-8 text-center px-1.5 py-0.5 rounded-lg ${
                        isLow ? 'bg-amber-100 text-amber-600' : 'bg-emerald-50 text-emerald-600'
                      }`}>
                        {p.stock}
                      </span>
                      <button
                        onClick={() => handleQuickAddStock(p.id, 5)}
                        className="px-1.5 py-0.5 rounded-full text-[9px] font-bold text-zinc-500 hover:text-emerald-500 cursor-pointer"
                        title="Add stock by 5"
                      >
                        +5
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* SECTION 2: ORDERS FULFILLMENT LOGS */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          <h3 className="font-extrabold text-sm text-neutral-800 dark:text-white">Active Order Pipelines</h3>

          {orders.length === 0 ? (
            <div className="py-12 text-center text-zinc-400 text-xs">
              No product sales checkout entries registered yet.
            </div>
          ) : (
            <div className="space-y-3">
              {orders.map((or) => (
                <div
                  key={or.id}
                  className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800/80 p-4 rounded-3xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 text-xs"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-[11px]">
                      <span className="font-mono font-black">{or.id}</span>
                      <span className="text-zinc-400 font-bold">Total Val: <span className="text-rose-500">${or.total.toFixed(2)}</span></span>
                      <span className={`px-2 py-0.5 rounded-full text-[8px] font-bold uppercase ${
                        or.status === 'ordered' ? 'bg-indigo-50 text-indigo-600' : 'bg-emerald-50 text-emerald-600'
                      }`}>
                        {or.status}
                      </span>
                    </div>
                    {/* Items label strings */}
                    <p className="text-[10px] text-zinc-500 truncate max-w-sm">{or.items.map(it => `${it.product.name} (x${it.quantity})`).join(', ')}</p>
                    <p className="text-[9px] text-zinc-400">Recipient: <span className="font-bold">{or.shippingAddress.fullName}</span>, PIN: {or.shippingAddress.postalCode}, Tel: {or.shippingAddress.phone}</p>
                  </div>

                  {or.status === 'ordered' ? (
                    <button
                      onClick={() => handleCompleteOrder(or.id)}
                      className="w-full sm:w-auto px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                    >
                      <Check className="h-3.5 w-3.5" />
                      Dispatch Logistics
                    </button>
                  ) : (
                    <span className="text-[10px] text-zinc-400 font-bold uppercase">Dispatched & Resolved</span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* SECTION 3: PUSH BROADCASTER */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'push' && (
        <div className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800 p-6 rounded-3xl max-w-lg mx-auto space-y-4">
          <div className="flex items-center gap-2">
            <BellRing className="h-5 w-5 text-pink-500" />
            <h3 className="font-extrabold text-sm text-neutral-800 dark:text-zinc-100">FCM Broadcast Centre</h3>
          </div>
          
          <p className="text-zinc-500 dark:text-zinc-400 text-xs leading-relaxed">
            Send farm announcements, flash sale alerts, or tour openings directly to all active customers. This mimics real-time Firebase Cloud Messaging banners inside our preview browser space!
          </p>

          <form onSubmit={handleTriggerPush} className="space-y-4 text-xs">
            <div className="space-y-1">
              <label htmlFor="broadcast-message-text" className="font-bold text-zinc-400 text-[10px] uppercase tracking-wider block">Notification Alert Banner Text</label>
              <textarea
                id="broadcast-message-text"
                required
                rows={3}
                value={broadcastMessage}
                onChange={(e) => setBroadcastMessage(e.target.value)}
                placeholder="🔥 Flash Sale: Organic Golden Solars are 20% off for the next 2 hours! Free juice bottle with checkout!"
                className="w-full p-3.5 bg-neutral-50 dark:bg-zinc-800 border-none outline-none focus:ring-1 focus:ring-pink-500 rounded-2xl resize-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-full bg-pink-500 hover:bg-pink-600 text-white font-black tracking-wide shadow-lg shadow-pink-500/20 text-center flex items-center justify-center gap-2 cursor-pointer text-xs"
            >
              <Sparkles className="h-4.5 w-4.5 animate-pulse" />
              Broadcast Notification Flash
            </button>
          </form>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* SECTION 4: SYSTEM USERS INDEX */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <h3 className="font-extrabold text-sm text-neutral-800 dark:text-white">Active Farmstead Directory</h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {systemUsers.map((su) => (
              <div
                key={su.uid}
                className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800 p-4 rounded-3xl shadow-sm text-xs flex justify-between items-center"
              >
                <div>
                  <h4 className="font-extrabold text-zinc-800 dark:text-zinc-100 leading-tight">{su.displayName}</h4>
                  <p className="text-[10px] text-zinc-400 mt-0.5">{su.email}</p>
                </div>
                <span className={`px-2.5 py-1 text-[9px] font-black uppercase rounded-full ${
                  su.role === 'Admin'
                    ? 'bg-rose-50 text-rose-500'
                    : su.role === 'Farm Worker'
                    ? 'bg-emerald-50 text-emerald-600 shadow-sm'
                    : 'bg-neutral-50 text-zinc-500'
                }`}>
                  {su.role}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}
