import React, { useState, useEffect } from 'react';
import { ShoppingBag, X, Plus, Minus, Trash, MapPin, Receipt, CreditCard, Search, ArrowRight, ShieldCheck, CheckCircle2, Truck, Calendar, Sparkles } from 'lucide-react';
import { CartItem, Order, UserProfile } from '../types';
import { dbService } from '../dbService';

interface EcommerceFlowProps {
  cart: CartItem[];
  currentTabState: string;
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveFromCart: (productId: string) => void;
  onClearCart: () => void;
  user: UserProfile | null;
  onNavigate: (tab: string) => void;
}

export default function EcommerceFlow({
  cart,
  currentTabState,
  onUpdateQuantity,
  onRemoveFromCart,
  onClearCart,
  user,
  onNavigate
}: EcommerceFlowProps) {
  const [activeSubTab, setActiveSubTab] = useState<'cart' | 'checkout' | 'tracking' | 'history'>('cart');
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeOrderForTracking, setActiveOrderForTracking] = useState<Order | null>(null);
  
  // Checkout Address info
  const [fullName, setFullName] = useState(user?.displayName || '');
  const [addressLine, setAddressLine] = useState('');
  const [city, setCity] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [phone, setPhone] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'upi' | 'wallet'>('card');
  const [isProcessingCheckout, setIsProcessingCheckout] = useState(false);

  // Math totals
  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const deliveryFee = subtotal > 30 ? 0 : 5.99; // Free delivery above $30
  const total = subtotal + deliveryFee;

  useEffect(() => {
    if (currentTabState === 'cart') {
      setActiveSubTab('cart');
    }
  }, [currentTabState]);

  useEffect(() => {
    // Load local history
    dbService.getOrders().then(item => {
      setOrders(item);
      if (item.length > 0) {
        setActiveOrderForTracking(item[0]);
      }
    });
  }, [cart, activeSubTab]);

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0 || !user) return;

    if (!addressLine || !city || !postalCode || !phone) {
      alert("Please complete all shipping address fields.");
      return;
    }

    setIsProcessingCheckout(true);
    
    // Simulate payment response delay
    setTimeout(async () => {
      const paymentId = paymentMethod === 'upi' ? `upi_bloom_${Math.floor(1000 + Math.random() * 9000)}` : `ch_stripe_${Math.floor(1000 + Math.random() * 9000)}`;
      
      const newOrderData = {
        userId: user.uid,
        items: [...cart],
        subtotal,
        deliveryFee,
        total,
        status: 'ordered' as const,
        shippingAddress: {
          fullName,
          addressLine,
          city,
          postalCode,
          phone
        },
        paymentMethod,
        paymentId
      };

      try {
        const order = await dbService.createOrder(newOrderData);
        setOrders(prev => [order, ...prev]);
        setActiveOrderForTracking(order);
        onClearCart();
        setActiveSubTab('tracking');
      } catch (err) {
        console.error(err);
      } finally {
        setIsProcessingCheckout(false);
      }
    }, 2000);
  };

  const selectOrderForTracking = (ord: Order) => {
    setActiveOrderForTracking(ord);
    setActiveSubTab('tracking');
  };

  return (
    <div className="py-6 px-4 max-w-4xl mx-auto space-y-6">
      
      {/* Tab Navigation header */}
      <div className="flex items-center gap-2 border-b border-neutral-200 dark:border-zinc-800 pb-2.5 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveSubTab('cart')}
          className={`px-4 py-2 text-xs font-bold rounded-full transition-all cursor-pointer ${
            activeSubTab === 'cart'
              ? 'bg-pink-500 text-white shadow-md shadow-pink-500/10'
              : 'text-zinc-600 dark:text-zinc-400 hover:bg-neutral-50 dark:hover:bg-zinc-800'
          }`}
        >
          Shopping Cart ({cart.length})
        </button>
        <button
          onClick={() => cart.length > 0 && setActiveSubTab('checkout')}
          disabled={cart.length === 0}
          className={`px-4 py-2 text-xs font-bold rounded-full transition-all cursor-pointer ${
            activeSubTab === 'checkout'
              ? 'bg-pink-500 text-white shadow-md'
              : 'text-zinc-400 dark:text-zinc-600 cursor-not-allowed'
          }`}
        >
          Secure Checkout
        </button>
        <button
          onClick={() => activeOrderForTracking && setActiveSubTab('tracking')}
          disabled={!activeOrderForTracking}
          className={`px-4 py-2 text-xs font-bold rounded-full transition-all cursor-pointer ${
            activeSubTab === 'tracking'
              ? 'bg-pink-500 text-white shadow-md'
              : 'text-zinc-400 dark:text-zinc-600 cursor-not-allowed'
          }`}
        >
          Order Tracking
        </button>
        <button
          onClick={() => setActiveSubTab('history')}
          className={`px-4 py-2 text-xs font-bold rounded-full transition-all cursor-pointer ${
            activeSubTab === 'history'
              ? 'bg-pink-500 text-white shadow-md'
              : 'text-zinc-600 dark:text-zinc-400 hover:bg-neutral-50 dark:hover:bg-zinc-800'
          }`}
        >
          Order History ({orders.length})
        </button>
      </div>

      {/* ---------------------------------------------------- */}
      {/* SUB-TAB 1: CART LIST VIEW */}
      {/* ---------------------------------------------------- */}
      {activeSubTab === 'cart' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Main items panel */}
          <div className="md:col-span-2 space-y-4">
            {cart.length === 0 ? (
              <div className="text-center py-16 bg-white dark:bg-zinc-900 border border-neutral-100 dark:border-zinc-800/80 rounded-3xl space-y-4 p-6">
                <div className="h-16 w-16 bg-pink-100 dark:bg-pink-900/30 rounded-full flex items-center justify-center mx-auto text-pink-500">
                  <ShoppingBag className="h-7 w-7" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-neutral-800 dark:text-zinc-100">Your Basket is Empty</h3>
                  <p className="text-zinc-500 dark:text-zinc-400 text-xs">Fill it with sweet golden pitayas and composts!</p>
                </div>
                <button
                  onClick={() => onNavigate('shop')}
                  className="px-6 py-2.5 rounded-full bg-emerald-600 font-bold text-xs text-white cursor-pointer"
                >
                  Go to Marketplace
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {cart.map((item) => (
                  <div
                    key={item.product.id}
                    className="flex gap-4 items-center bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800/60 p-4 rounded-3xl"
                  >
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="h-16 w-16 object-cover rounded-2xl bg-neutral-100 dark:bg-zinc-950 flex-shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    
                    <div className="flex-1 min-w-0">
                      <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest block">{item.product.category}</span>
                      <h4 className="font-bold text-sm text-zinc-900 dark:text-zinc-100 truncate">{item.product.name}</h4>
                      <p className="text-xs font-black text-rose-500">${item.product.price}</p>
                    </div>

                    {/* Quantity Selector controls */}
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, -1)}
                        className="p-1 h-7 w-7 rounded-full bg-neutral-50 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 flex items-center justify-center border border-neutral-200/30 cursor-pointer"
                      >
                        <Minus className="h-3 w-3" />
                      </button>
                      <span className="text-xs font-bold text-zinc-800 dark:text-zinc-200 min-w-4 text-center">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, 1)}
                        className="p-1 h-7 w-7 rounded-full bg-neutral-50 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 flex items-center justify-center border border-neutral-200/30 cursor-pointer"
                      >
                        <Plus className="h-3 w-3" />
                      </button>
                    </div>

                    <button
                      onClick={() => onRemoveFromCart(item.product.id)}
                      className="p-2 text-zinc-400 hover:text-red-500 rounded-lg cursor-pointer"
                      title="Delete Item"
                    >
                      <Trash className="h-4.5 w-4.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Checkout total summaries card */}
          {cart.length > 0 && (
            <div className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800/60 p-6 rounded-3xl h-fit space-y-6">
              <h3 className="font-extrabold text-sm text-neutral-800 dark:text-blue-50">E-Commerce Summary</h3>
              
              <div className="space-y-2.5 text-xs text-zinc-600 dark:text-zinc-400">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-bold text-zinc-800 dark:text-zinc-200">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Delivery Fee</span>
                  <span className="font-bold text-zinc-800 dark:text-zinc-200">
                    {deliveryFee === 0 ? <span className="text-emerald-500">FREE</span> : `$${deliveryFee.toFixed(2)}`}
                  </span>
                </div>
                {deliveryFee > 0 && (
                  <p className="text-[10px] text-zinc-400 text-right italic font-normal">Add ${(30 - subtotal).toFixed(2)} more for FREE delivery!</p>
                )}
                <div className="border-t border-neutral-100 dark:border-zinc-800 pt-3 flex justify-between text-sm">
                  <span className="font-extrabold text-zinc-900 dark:text-white">Order Total</span>
                  <span className="font-black text-rose-500">${total.toFixed(2)}</span>
                </div>
              </div>

              {/* Loyalty reward projections */}
              <div className="bg-emerald-500/5 border border-emerald-500/20 rounded-2xl p-3 flex items-start gap-2 text-[11px] text-emerald-800 dark:text-emerald-400">
                <Sparkles className="h-4 w-4 mt-0.5 animate-pulse text-emerald-600" />
                <div>
                  <span className="font-bold">Earn Loyalty Points!</span>
                  <p className="text-[10px] text-zinc-400 mt-1">Completing this order earns you <span className="font-bold text-emerald-600">{Math.floor(total * 5)} points</span> towards free tour entries.</p>
                </div>
              </div>

              <button
                id="proceed-to-checkout-btn"
                onClick={() => setActiveSubTab('checkout')}
                className="w-full py-3.5 rounded-full bg-pink-500 hover:bg-pink-600 text-white font-bold text-xs tracking-wide shadow-lg shadow-pink-500/20 text-center flex items-center justify-center gap-2 cursor-pointer"
              >
                Proceed to Secure Checkout
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* SUB-TAB 2: SECURE CHECKOUT FLOW */}
      {/* ---------------------------------------------------- */}
      {activeSubTab === 'checkout' && (
        <form onSubmit={handlePlaceOrder} className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Form left */}
          <div className="md:col-span-2 space-y-4">
            <div className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800/60 p-6 rounded-3xl space-y-4">
              <div className="flex items-center gap-2 border-b border-neutral-100 dark:border-zinc-800 pb-2">
                <MapPin className="h-5 w-5 text-emerald-600" />
                <h3 className="font-extrabold text-sm text-neutral-800 dark:text-blue-50">Shipping Address</h3>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="col-span-2 space-y-1">
                  <label htmlFor="checkout-full-name" className="font-semibold text-zinc-400 uppercase tracking-widest text-[10px]">Full Recipient Name</label>
                  <input
                    id="checkout-full-name"
                    required
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Kumar Soumyanarayan"
                    className="w-full p-2.5 bg-neutral-50 dark:bg-zinc-800 border-none outline-none focus:ring-1 focus:ring-pink-500 rounded-lg text-zinc-800 dark:text-zinc-200"
                  />
                </div>
                <div className="col-span-2 space-y-1">
                  <label htmlFor="checkout-street" className="font-semibold text-zinc-400 uppercase tracking-widest text-[10px]">Street Address</label>
                  <input
                    id="checkout-street"
                    required
                    type="text"
                    value={addressLine}
                    onChange={(e) => setAddressLine(e.target.value)}
                    placeholder="Line 1, Plot No 42, Orchards Lane"
                    className="w-full p-2.5 bg-neutral-50 dark:bg-zinc-800 border-none outline-none focus:ring-1 focus:ring-pink-500 rounded-lg text-zinc-800 dark:text-zinc-200"
                  />
                </div>
                <div className="space-y-1">
                  <label htmlFor="checkout-city" className="font-semibold text-zinc-400 uppercase tracking-widest text-[10px]">City</label>
                  <input
                    id="checkout-city"
                    required
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="Bhubaneswar"
                    className="w-full p-2.5 bg-neutral-50 dark:bg-zinc-800 border-none outline-none focus:ring-1 focus:ring-pink-500 rounded-lg text-zinc-800 dark:text-zinc-200"
                  />
                </div>
                <div className="space-y-1">
                  <label htmlFor="checkout-postal-code" className="font-semibold text-zinc-400 uppercase tracking-widest text-[10px]">Postal PIN / Zip Code</label>
                  <input
                    id="checkout-postal-code"
                    required
                    type="text"
                    value={postalCode}
                    onChange={(e) => setPostalCode(e.target.value)}
                    placeholder="751001"
                    className="w-full p-2.5 bg-neutral-50 dark:bg-zinc-800 border-none outline-none focus:ring-1 focus:ring-pink-500 rounded-lg text-zinc-800 dark:text-zinc-200"
                  />
                </div>
                <div className="col-span-2 space-y-1">
                  <label htmlFor="checkout-phone" className="font-semibold text-zinc-400 uppercase tracking-widest text-[10px]">Contact Mobile Phone</label>
                  <input
                    id="checkout-phone"
                    required
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="w-full p-2.5 bg-neutral-50 dark:bg-zinc-800 border-none outline-none focus:ring-1 focus:ring-pink-500 rounded-lg text-zinc-800 dark:text-zinc-200"
                  />
                </div>
              </div>
            </div>

            {/* Payment Options Gate */}
            <div className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800/60 p-6 rounded-3xl space-y-4">
              <div className="flex items-center gap-2 border-b border-neutral-100 dark:border-zinc-800 pb-2">
                <CreditCard className="h-5 w-5 text-emerald-600" />
                <h3 className="font-extrabold text-sm text-neutral-800 dark:text-blue-50">Verified Gateway Integrations</h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { id: 'card', label: 'Credit/Debit Card (Stripe)', desc: 'Pre-gated Sandbox secure link' },
                  { id: 'upi', label: 'Instant UPI (Razorpay IMPS)', desc: 'Bypasses wallet holds' },
                ].map((mt) => (
                  <button
                    key={mt.id}
                    type="button"
                    onClick={() => setPaymentMethod(mt.id as any)}
                    className={`p-3 rounded-2xl border text-left flex flex-col justify-between h-24 cursor-pointer ${
                      paymentMethod === mt.id
                        ? 'bg-pink-500/5 border-pink-500 text-pink-500'
                        : 'bg-neutral-50 dark:bg-zinc-900/50 border-neutral-200 dark:border-zinc-800 text-zinc-600'
                    }`}
                  >
                    <span className="text-xs font-black">{mt.label}</span>
                    <span className="text-[9px] text-zinc-400 leading-snug">{mt.desc}</span>
                  </button>
                ))}
              </div>

              {paymentMethod === 'card' ? (
                <div className="p-4 bg-neutral-50 dark:bg-zinc-800/50 rounded-2xl grid grid-cols-3 gap-3 text-xs text-zinc-600">
                  <div className="col-span-3 space-y-1">
                    <label htmlFor="cc-number-mock" className="font-semibold text-zinc-400 text-[9px] uppercase tracking-wider block">Credit Card Number (Mocked Sandbox)</label>
                    <input
                      id="cc-number-mock"
                      disabled
                      type="text"
                      className="w-full p-2 bg-neutral-100 dark:bg-zinc-800 border-none text-[11px] font-mono rounded"
                      value="4242 •••• •••• 1205"
                    />
                  </div>
                  <div className="space-y-1">
                    <label htmlFor="cc-expiry-mock" className="font-semibold text-zinc-400 text-[9px] uppercase tracking-wider block">Expiry</label>
                    <input id="cc-expiry-mock" disabled type="text" className="w-full p-2 bg-neutral-100 dark:bg-zinc-800 border-none text-[11px] font-mono rounded" value="12/30" />
                  </div>
                  <div className="space-y-1">
                    <label htmlFor="cc-cvv-mock" className="font-semibold text-zinc-400 text-[9px] uppercase tracking-wider block">CVV</label>
                    <input id="cc-cvv-mock" disabled type="text" className="w-full p-2 bg-neutral-100 dark:bg-zinc-800 border-none text-[11px] font-mono text-center rounded" value="***" />
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-neutral-50 dark:bg-zinc-800/50 rounded-2xl space-y-1 text-xs text-zinc-600">
                  <label htmlFor="upi-id-mock" className="font-bold text-zinc-400 text-[9px] uppercase tracking-widest block">Razorpay UPI ID</label>
                  <input
                    id="upi-id-mock"
                    type="text"
                    required
                    placeholder="jshb@okhdfc"
                    className="w-full p-2 bg-white dark:bg-zinc-900 border-none text-[11px] rounded"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Form right summary view */}
          <div className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800/60 p-6 rounded-3xl h-fit space-y-6">
            <h3 className="font-extrabold text-sm text-neutral-800 dark:text-blue-50">Review Billing Checklist</h3>
            
            <div className="space-y-3.5 border-b border-neutral-100 dark:border-zinc-800 pb-4 max-h-48 overflow-y-auto">
              {cart.map((item) => (
                <div key={item.product.id} className="flex justify-between items-center text-xs">
                  <span className="truncate max-w-[130px] font-medium text-zinc-700 dark:text-zinc-300">{item.product.name} × {item.quantity}</span>
                  <span className="font-bold text-rose-500">${(item.product.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>

            <div className="space-y-2 text-xs text-zinc-600 dark:text-zinc-400">
              <div className="flex justify-between">
                <span>Cart Valuation</span>
                <span className="font-bold">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Green Logistics Fee</span>
                <span>{deliveryFee === 0 ? <span className="text-emerald-500 font-bold">FREE</span> : `$${deliveryFee.toFixed(2)}`}</span>
              </div>
              <div className="flex justify-between text-sm font-black border-t border-neutral-100 dark:border-zinc-800 pt-2 text-zinc-900 dark:text-white">
                <span>Grand Total</span>
                <span className="text-rose-500">${total.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex gap-2 p-3 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl text-[10px] text-zinc-500 leading-relaxed">
              <ShieldCheck className="h-4.5 w-4.5 text-emerald-600 flex-shrink-0" />
              <span>Payment is fully sandboxed. No actual currency is charged on your account.</span>
            </div>

            <button
              id="confirm-checkout-btn"
              type="submit"
              disabled={isProcessingCheckout}
              className={`w-full py-3.5 rounded-full bg-emerald-600 text-white font-bold text-xs tracking-wide shadow-lg shadow-emerald-600/10 flex items-center justify-center gap-2 cursor-pointer ${
                isProcessingCheckout ? 'opacity-50 cursor-not-allowed bg-zinc-500' : 'hover:bg-emerald-700'
              }`}
            >
              {isProcessingCheckout ? (
                <>
                  <span className="h-3 w-3 rounded-full border-2 border-white border-t-transparent animate-spin" />
                  Processing Safe Gateway Escrow...
                </>
              ) : (
                <>
                  Submit Secure Payment
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </button>
            
            <button
              onClick={() => setActiveSubTab('cart')}
              type="button"
              className="w-full text-center text-xs font-bold text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300 transform transition-colors cursor-pointer"
            >
              Back to edit basket
            </button>
          </div>
        </form>
      )}

      {/* ---------------------------------------------------- */}
      {/* SUB-TAB 3: ORDER TRACKING TIMELINE / ACTIVE INVOICE */}
      {/* ---------------------------------------------------- */}
      {activeSubTab === 'tracking' && activeOrderForTracking && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Tracking state map */}
          <div className="md:col-span-2 bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800/60 p-6 rounded-3xl space-y-6">
            <div className="flex items-center justify-between border-b border-neutral-100 dark:border-zinc-800 pb-3">
              <div>
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest leading-none">Vessels Tracker</span>
                <h3 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100">{activeOrderForTracking.id} Tracking Status</h3>
              </div>
              <span className="px-3 py-1 bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400 rounded-full font-bold text-[10px] uppercase">
                {activeOrderForTracking.status}
              </span>
            </div>

            {/* Stepper block */}
            <div className="space-y-6 py-4">
              {[
                { step: 'ordered', label: 'Order Confirmed', desc: 'Secure escrow authorized checkout', done: true },
                { step: 'processing', label: 'Farm Extraction & Packing', desc: 'Slicing under clean standards', done: activeOrderForTracking.status !== 'ordered' },
                { step: 'shipped', label: 'Vessel Transiting', desc: 'Dispatched to target hub', done: ['shipped', 'delivered'].includes(activeOrderForTracking.status) },
                { step: 'delivered', label: 'Delivered', desc: 'Fresh item dropped off safely', done: activeOrderForTracking.status === 'delivered' }
              ].map((st, i) => (
                <div key={i} className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className={`h-7 w-7 rounded-full flex items-center justify-center border-2 ${
                      st.done
                        ? 'bg-emerald-600 border-emerald-600 text-white animate-pulse'
                        : 'bg-neutral-50 dark:bg-zinc-950 border-neutral-200 dark:border-zinc-800 text-zinc-300'
                    }`}>
                      <CheckCircle2 className="h-4.5 w-4.5" />
                    </div>
                    {i < 3 && (
                      <div className={`w-0.5 h-12 ${
                        st.done ? 'bg-emerald-600' : 'bg-neutral-200 dark:bg-zinc-800'
                      }`} />
                    )}
                  </div>
                  <div className="pt-0.5 space-y-0.5">
                    <h4 className={`text-xs font-bold ${st.done ? 'text-zinc-900 dark:text-zinc-100' : 'text-zinc-400'}`}>{st.label}</h4>
                    <p className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-snug">{st.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Shipping destinations display */}
            <div className="bg-neutral-50 dark:bg-zinc-950 p-4 rounded-2xl grid grid-cols-2 gap-4 text-xs text-zinc-600 dark:text-zinc-400">
              <div>
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block mb-1">Shipping Target</span>
                <span className="font-extrabold text-zinc-800 dark:text-zinc-200 block">{activeOrderForTracking.shippingAddress.fullName}</span>
                <span className="block text-[11px] leading-relaxed mt-1">{activeOrderForTracking.shippingAddress.addressLine}, {activeOrderForTracking.shippingAddress.city} - {activeOrderForTracking.shippingAddress.postalCode}</span>
              </div>
              <div>
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block mb-1">Escrow payment ID</span>
                <span className="font-mono text-[10px] text-zinc-500 block truncate">{activeOrderForTracking.paymentId}</span>
                <span className="block text-[11px] mt-1">Authorized Method: <span className="font-bold uppercase text-emerald-600">{activeOrderForTracking.paymentMethod}</span></span>
              </div>
            </div>
          </div>

          {/* Printable Invoice View Frame */}
          <div className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800/60 rounded-3xl p-6 self-start space-y-4">
            <div className="flex items-center gap-2 border-b border-neutral-100 dark:border-zinc-800 pb-2">
              <Receipt className="h-4.5 w-4.5 text-pink-500" />
              <h3 className="font-extrabold text-sm text-zinc-800 dark:text-blue-50">Invoice Generator</h3>
            </div>

            {/* Simulated invoice bill sheet */}
            <div id="print-invoice-bill" className="bg-neutral-50 dark:bg-zinc-950 p-4 rounded-2xl border border-neutral-200/40 dark:border-zinc-800/40 text-xs text-zinc-700 space-y-4 font-mono relative overflow-hidden">
              <div className="text-center pb-2 border-b border-dashed border-neutral-200 dark:border-zinc-800">
                <span className="font-bold text-zinc-900 dark:text-zinc-100 tracking-wide text-xs block">JS Horticulture</span>
                <span className="text-[9px] text-zinc-400 font-bold uppercase tracking-wider text-[#2D5A3F] dark:text-[#FF4D8D]">JS Horticulture</span>
              </div>

              <div className="space-y-1 text-[10px] text-zinc-500">
                <div>Order: {activeOrderForTracking.id}</div>
                <div>Date: {new Date(activeOrderForTracking.createdAt).toLocaleDateString()}</div>
                <div>Terms: Sandbox Pre-Paid</div>
              </div>

              <div className="space-y-2 text-[10px] border-b border-dashed border-neutral-200 dark:border-zinc-800 pb-2">
                {activeOrderForTracking.items.map((it, i) => (
                  <div key={i} className="flex justify-between">
                    <span className="truncate max-w-[125px]">{it.product.name} ×{it.quantity}</span>
                    <span>${(it.product.price * it.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>

              <div className="space-y-1 text-[10px] text-right">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>${activeOrderForTracking.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Logistics</span>
                  <span>${activeOrderForTracking.deliveryFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-black text-rose-500 text-xs border-t border-dashed border-neutral-200 dark:border-zinc-800 pt-1">
                  <span>Total Bill</span>
                  <span>${activeOrderForTracking.total.toFixed(2)}</span>
                </div>
              </div>

              <div className="text-center pt-2 border-t border-dashed border-neutral-200 dark:border-zinc-800 text-[9px] text-zinc-400">
                Thank you for supporting organic!
              </div>
            </div>

            <button
              onClick={() => window.print()}
              className="w-full py-2.5 rounded-full border border-neutral-200 dark:border-zinc-800 hover:bg-neutral-50 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
            >
              Print Official Invoice
            </button>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* SUB-TAB 4: USER HISTORY LIST */}
      {/* ---------------------------------------------------- */}
      {activeSubTab === 'history' && (
        <div className="space-y-4">
          {orders.length === 0 ? (
            <div className="text-center py-16 bg-white dark:bg-zinc-900 border border-neutral-100 dark:border-zinc-800/80 rounded-3xl space-y-3 p-6">
              <div className="h-12 w-12 bg-neutral-100 dark:bg-zinc-800 rounded-full flex items-center justify-center mx-auto text-zinc-400">
                <Truck className="h-5 w-5" />
              </div>
              <p className="text-zinc-500 dark:text-zinc-400 text-xs font-bold">You have placed no prior orders on this profile.</p>
              <button
                onClick={() => onNavigate('shop')}
                className="px-4 py-2 rounded-full bg-pink-500 text-white text-xs font-bold"
              >
                Start Shopping Now
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {orders.map((or) => (
                <div
                  key={or.id}
                  className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800/60 p-4 rounded-3xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 hover:shadow-md transition-shadow"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-xs text-zinc-900 dark:text-zinc-100">{or.id}</span>
                      <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400 text-[9px] uppercase font-bold">{or.status}</span>
                    </div>
                    <p className="text-[10px] text-zinc-400 flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      Ordered: {new Date(or.createdAt).toLocaleDateString()}
                    </p>
                    <span className="text-[10px] text-zinc-500 block truncate max-w-xs">{or.items.map(it => `${it.product.name} (x${it.quantity})`).join(', ')}</span>
                  </div>

                  <div className="flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto gap-2">
                    <span className="text-sm font-black text-rose-500">${or.total.toFixed(2)}</span>
                    <button
                      onClick={() => selectOrderForTracking(or)}
                      className="px-3.5 py-1.5 bg-neutral-100 dark:bg-zinc-800 hover:bg-neutral-200 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 rounded-full text-[10px] font-bold cursor-pointer"
                    >
                      Track Order & Bill
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

    </div>
  );
}
