import { ArrowRight, TreePine, ShieldCheck, Milestone, CheckCircle2, Star, Award, Leaf } from 'lucide-react';
import { motion } from 'motion/react';

interface HeroSectionProps {
  onNavigate: (tab: string) => void;
}

const TESTIMONIALS = [
  {
    quote: "JS Horticulture’s Royal Magenta fruit is a masterpiece of agriculture. The Brix sweetness is unparalleled. We use it in all our signature desserts.",
    author: "Chef Michel L'Aura",
    title: "Michelin Star Pastry Chef, Oasis Bistro",
    stars: 5,
    avatar: "https://images.unsplash.com/photo-1577219491135-ce391730fb2c?w=100&auto=format&fit=crop"
  },
  {
    quote: "The tour was magical! Walking beneath huge blooming trellises lit up in the evening moonlight is a trip my kids will never forget.",
    author: "Elena Petrova",
    title: "Family Trellis Explorer, Seattle",
    stars: 5,
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop"
  },
  {
    quote: "Amazing compost and premium saplings. My backyard dragon fruits have grown three times faster since using their bio-fertilizer active mix.",
    author: "Dr. Gregory Vance",
    title: "Urban Agriculturist, Portland",
    stars: 5,
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop"
  }
];

const BADGES = [
  { text: '100% Certified Organic', icon: Leaf },
  { text: 'Rich in Antioxidants', icon: ShieldCheck },
  { text: 'Eco-Friendly Farming', icon: TreePine },
  { text: 'Zero Toxin Pledge', icon: CheckCircle2 }
];

export default function HeroSection({ onNavigate }: HeroSectionProps) {
  return (
    <div className="relative font-sans">
      
      {/* 1. Cinematic Hero Section with Parallax Backdrop */}
      <section className="relative h-[90vh] min-h-[580px] flex items-center justify-center overflow-hidden">
        {/* Visual Background */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=1600&auto=format&fit=crop&q=80"
            alt="JS Horticulture cinematic vines backdrop"
            className="w-full h-full object-cover brightness-40 saturate-[1.1] scale-105 transition-transform duration-10000"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-[#1B3022]/40 to-[#FDFBF7] dark:to-[#0C140F]" />
        </div>

        {/* Cinematic Content Hub */}
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          {/* Farm Label Tag */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-white/10 dark:bg-[#1B3022]/20 backdrop-blur-md rounded-full border border-white/20 text-[#FF4D8D] dark:text-pink-300 font-bold text-xs tracking-widest uppercase mb-6"
          >
            <Leaf className="h-3.5 w-3.5" />
            JS Horticulture
          </motion.div>

          {/* Epic Main Header Banner */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.8 }}
            className="text-4xl sm:text-6xl font-black text-white mb-6 leading-tight select-none"
          >
            Fresh Organic
            <span className="block mt-2 bg-gradient-to-r from-[#FF4D8D] to-[#D4145A] bg-clip-text text-transparent italic">
              Dragon Fruits
            </span>
            Direct From Farm
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.7 }}
            className="text-neutral-200 text-sm sm:text-lg max-w-xl mx-auto mb-4 font-medium leading-relaxed"
          >
            Indulge in sweet, farm-to-table Royal Pitayas packed with natural nectar, cultivated through deep eco-conservation and smart-micro drip irrigation technology.
          </motion.p>

          {/* Central Owner Proprieters Badge */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.35, duration: 0.7 }}
            className="text-[11px] text-[#F3F6F4]/95 font-semibold tracking-wider mb-8 uppercase flex items-center justify-center gap-2 flex-wrap"
          >
            <span className="opacity-70">Curated &amp; Owned by:</span>
            <span className="bg-white/10 dark:bg-zinc-950/45 px-2.5 py-1 rounded-full text-white border border-white/10 font-bold hover:text-[#FF4D8D] transition-colors">
              Kumar Jyoti Narayan
            </span>
            <span className="opacity-50">&amp;</span>
            <span className="bg-white/10 dark:bg-zinc-950/45 px-2.5 py-1 rounded-full text-white border border-white/10 font-bold hover:text-[#FF4D8D] transition-colors">
              Santosh Kumar Behera
            </span>
          </motion.div>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.45 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 px-4"
          >
            <button
              id="hero-shop-cta"
              onClick={() => onNavigate('shop')}
              className="w-full sm:w-auto px-8 py-3.5 rounded-full pink-gradient hover:opacity-90 hover:scale-105 text-white font-bold tracking-wide shadow-lg shadow-pink-500/10 transform active:scale-95 transition-all text-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              Order Farm Products
              <ArrowRight className="h-4 w-4" />
            </button>
            <button
              id="hero-booking-cta"
              onClick={() => onNavigate('booking')}
              className="w-full sm:w-auto px-8 py-3.5 rounded-full glass hover:bg-[#FDFBF7]/20 text-[#1B3022] dark:text-white font-extrabold tracking-wide transform active:scale-95 transition-all text-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              Book Farm Visit
            </button>
          </motion.div>
        </div>
      </section>

      {/* 2. Glassmorphism Benefits Matrix */}
      <section className="relative z-20 -mt-16 px-4 max-w-6xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-[#ffffff]/90 dark:bg-[#111e16]/90 backdrop-blur-xl border border-[#1B3022]/10 dark:border-white/10 rounded-3xl p-6 shadow-xl">
          {BADGES.map((b, i) => {
            const Icon = b.icon;
            return (
              <div key={i} className="flex flex-col items-center text-center p-3 hover:bg-[#1B3022]/5 dark:hover:bg-white/5 rounded-xl transition-all">
                <div className="h-10 w-10 flex items-center justify-center rounded-xl bg-[#2D5A3F]/15 dark:bg-[#2D5A3F]/30 text-[#1B3022] dark:text-emerald-400 mb-2">
                  <Icon className="h-5 w-5" />
                </div>
                <span className="text-xs sm:text-sm font-bold text-[#1B3022] dark:text-[#F3F6F4]">{b.text}</span>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. Farm story and cinematic showcase */}
      <section className="py-20 px-4 max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          
          <div className="space-y-6">
            <div className="inline-flex items-center gap-1 bg-[#2D5A3F]/10 dark:bg-[#2D5A3F]/25 text-[#1B3022] dark:text-emerald-400 font-bold text-xs px-3 py-1.5 rounded-full border border-[#1B3022]/10 dark:border-white/10">
              <Award className="h-3.5 w-3.5" />
              Sustainability Champion Since 2012
            </div>
            
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1B3022] dark:text-[#F3F6F4] tracking-tight leading-snug">
              Unfolding the Magic of the <span className="text-[#FF4D8D]">JS Horticulture Vine</span>
            </h2>
            
            <p className="text-zinc-650 dark:text-zinc-350 text-sm sm:text-base leading-relaxed">
              Nestled at the nutrient-rich valley, JS Horticulture was founded as an ecological reserve under the visionary path of owners <strong className="font-extrabold text-[#1B3022] dark:text-white">Kumar Jyoti Narayan</strong> and <strong className="font-extrabold text-[#1B3022] dark:text-white">Santosh Kumar Behera</strong>. Working with just six grafted red species vines, they guided our growth into a certified haven where we harness intelligent IoT farming technologies to protect our soil biome while delivering superior pitaya nectar profiles.
            </p>

            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="bg-[#ffffff] dark:bg-[#111e16] border border-[#1B3022]/8 dark:border-white/10 p-4 rounded-xl shadow-sm">
                <span className="block text-3xl font-black text-[#2D5A3F] dark:text-emerald-400">12+</span>
                <span className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Acres of Orchards</span>
              </div>
              <div className="bg-[#ffffff] dark:bg-[#111e16] border border-[#1B3022]/8 dark:border-white/10 p-4 rounded-xl shadow-sm">
                <span className="block text-3xl font-black text-[#FF4D8D]">4.9 ★</span>
                <span className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Customer Rating</span>
              </div>
            </div>

            <button
              onClick={() => onNavigate('learn')}
              className="inline-flex items-center gap-2 text-[#FF4D8D] hover:text-[#D4145A] font-bold text-sm group cursor-pointer"
            >
              Explore the Farming Learning Hub
              <ArrowRight className="h-4 w-4 transform group-hover:translate-x-1.5 transition-transform" />
            </button>
          </div>

          <div className="relative">
            {/* Visual Frame */}
            <div className="relative rounded-3xl overflow-hidden shadow-2xl aspect-video md:aspect-square">
              <img
                src="https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=800&auto=format&fit=crop&q=80"
                alt="JS Horticulture organic gardens"
                className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
              
              {/* Overlay Glass Badge */}
              <div className="absolute bottom-4 left-4 right-4 bg-white/75 dark:bg-[#111e16]/80 backdrop-blur-md border border-white/20 dark:border-white/10 p-4 rounded-2xl flex items-center justify-between text-[#1B3022] dark:text-white">
                <div>
                  <h4 className="font-extrabold text-sm">Tour bookings are open!</h4>
                  <p className="text-[10.5px] text-[#1B3022]/80 dark:text-zinc-300 font-medium">Reserve a magical sunset walk beneath the giant trellis.</p>
                </div>
                <button
                  onClick={() => onNavigate('booking')}
                  className="px-3.5 py-2.5 rounded-full pink-gradient text-white font-bold text-xs shadow-md transition-all cursor-pointer hover:opacity-90"
                >
                  Join Tour
                </button>
              </div>
            </div>
            
            {/* Backgound glow ring */}
            <div className="absolute -top-8 -right-8 h-40 w-40 bg-pink-400/10 dark:bg-pink-500/5 rounded-full blur-3xl z-[-1]" />
          </div>

        </div>
      </section>

      {/* 4. Organic Badges and Credo */}
      <section className="bg-gradient-to-tr from-emerald-500/5 via-pink-400/5 to-transparent py-16 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <h3 className="text-2xl font-black text-zinc-800 dark:text-zinc-200 tracking-tight mb-8">
            Nurtured by Nature, Proven by Quality
          </h3>
          <div className="flex flex-wrap items-center justify-center gap-8 md:gap-16 opacity-75 grayscale hover:grayscale-0 transition-all duration-300">
            {/* Eco Certifications List */}
            <div className="flex items-center gap-1.5 font-bold text-sm md:text-base text-zinc-700 dark:text-zinc-300">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              USDA ORGANIC
            </div>
            <div className="flex items-center gap-1.5 font-bold text-sm md:text-base text-zinc-700 dark:text-zinc-300">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              NON-GMO CERTIFIED
            </div>
            <div className="flex items-center gap-1.5 font-bold text-sm md:text-base text-zinc-700 dark:text-zinc-300">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              ZERO TOXIC OUTFLOW
            </div>
            <div className="flex items-center gap-1.5 font-bold text-sm md:text-base text-zinc-700 dark:text-zinc-300">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              ECOCERT GREEN
            </div>
          </div>
        </div>
      </section>

      {/* 5. Customer Testimonials */}
      <section className="py-20 px-4 max-w-6xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-extrabold tracking-widest text-pink-500 uppercase">Estuary Reviews</span>
          <h2 className="text-3xl font-black text-zinc-900 dark:text-zinc-100 tracking-tight mt-1">
            Endorsed by Gourmet Chefs & Families
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t, idx) => (
            <div
              key={idx}
              className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800/60 p-6 rounded-3xl shadow-md flex flex-col justify-between hover:shadow-lg transition-shadow duration-300"
            >
              <div>
                {/* Stars Indicator */}
                <div className="flex items-center gap-1 text-amber-500 mb-4">
                  {[...Array(t.stars)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-current" />
                  ))}
                </div>
                <p className="text-zinc-600 dark:text-zinc-400 text-sm italic leading-relaxed mb-6">
                  "{t.quote}"
                </p>
              </div>

              {/* Author Row */}
              <div className="flex items-center gap-3 pt-4 border-t border-neutral-100 dark:border-zinc-800">
                <img
                  src={t.avatar}
                  alt={t.author}
                  className="h-10 w-10 rounded-full object-cover ring-2 ring-emerald-500/20"
                />
                <div>
                  <h4 className="text-xs font-bold text-zinc-800 dark:text-zinc-200">{t.author}</h4>
                  <p className="text-[10px] text-zinc-400">{t.title}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}
