import React, { useState, useEffect } from 'react';
import { Mail, Phone, MapPin, Calendar, CheckSquare, Sparkles, Send, Trash, Compass, Check } from 'lucide-react';
import { dbService } from '../dbService';

interface ContactMessage {
  id: string;
  name: string;
  email: string;
  text: string;
  createdAt: string;
}

interface AboutAndContactProps {
  userRole: 'Customer' | 'Farm Worker' | 'Admin';
}

export default function AboutAndContact({ userRole }: AboutAndContactProps) {
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [activeTab, setActiveTab] = useState<'about' | 'contact' | 'inbox'>('about');
  
  // Contact Form states
  const [senderName, setSenderName] = useState('');
  const [senderEmail, setSenderEmail] = useState('');
  const [senderText, setSenderText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState(false);

  useEffect(() => {
    // Sync contact logs
    dbService.getContactMessages().then(setMessages);
    if (userRole === 'Admin' || userRole === 'Farm Worker') {
      setActiveTab('inbox');
    }
  }, [userRole]);

  const handleMessageSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!senderName || !senderEmail || !senderText) return;

    setIsSending(true);
    const msgPayload = {
      name: senderName.trim(),
      email: senderEmail.trim(),
      text: senderText.trim()
    };

    try {
      const created = await dbService.createContactMessage(msgPayload);
      setMessages(prev => [created, ...prev]);
      setSendSuccess(true);
      setSenderName('');
      setSenderEmail('');
      setSenderText('');
      setTimeout(() => setSendSuccess(false), 3000);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSending(false);
    }
  };

  const handleDeleteMsg = async (id: string) => {
    try {
      await dbService.deleteContactMessage(id);
      dbService.getContactMessages().then(setMessages);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="py-6 px-4 max-w-4xl mx-auto space-y-6">
      
      {/* Tab select row */}
      <div className="flex items-center gap-2 border-b border-neutral-200 dark:border-zinc-800 pb-2.5 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveTab('about')}
          className={`px-4 py-2 text-xs font-bold rounded-full transition-all cursor-pointer ${
            activeTab === 'about'
              ? 'bg-pink-500 text-white shadow-md shadow-pink-500/10'
              : 'text-zinc-600 dark:text-zinc-400 hover:bg-neutral-50 dark:hover:bg-zinc-800'
          }`}
        >
          About JS Horticulture
        </button>
        <button
          onClick={() => setActiveTab('contact')}
          className={`px-4 py-2 text-xs font-bold rounded-full transition-all cursor-pointer ${
            activeTab === 'contact'
              ? 'bg-pink-500 text-white shadow-md'
              : 'text-zinc-600 dark:text-zinc-400 hover:bg-neutral-50 dark:hover:bg-zinc-800'
          }`}
        >
          Contact Us Form
        </button>

        {/* Admin/worker inbox viewing panel */}
        {(userRole === 'Admin' || userRole === 'Farm Worker') && (
          <button
            onClick={() => setActiveTab('inbox')}
            className={`px-4 py-2 text-xs font-bold rounded-full transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'inbox'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-zinc-600 dark:text-zinc-400 hover:bg-neutral-50 dark:hover:bg-zinc-800'
            }`}
          >
            Inbound Messages Log ({messages.length})
          </button>
        )}
      </div>

      {/* ---------------------------------------------------- */}
      {/* SUB-TAB 1: ABOUT FARMHOUSE DESIGN DISPLAY */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'about' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
          <div className="space-y-4">
            <span className="text-[10px] font-extrabold tracking-widest text-[#5E7A68] uppercase">Physical Estate Specifications</span>
            <h2 className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-zinc-100 leading-snug">
              Uncompromising Standards & Pitaya Legacy
            </h2>
            <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 leading-relaxed">
              JS Horticulture was established by owners <strong className="font-extrabold text-zinc-800 dark:text-white">Kumar Jyoti Narayan</strong> and <strong className="font-extrabold text-zinc-800 dark:text-white">Santosh Kumar Behera</strong> in our beautiful sun-drenched coastal valley. Our mission has always been simple: produce elite magenta fruits of unparalleled sweetness profiles while maintaining a carbon-neutral biological loop that gives back to natural soil structure.
            </p>

            <div className="space-y-3 pt-2 text-xs text-zinc-600 dark:text-zinc-400">
              <div className="flex items-start gap-2.5">
                <MapPin className="h-4.5 w-4.5 text-pink-500 flex-shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-zinc-800 dark:text-zinc-200 block">Estates Location</span>
                  <span className="text-[11px] leading-snug">Orchards Lane, Row 12, Valley Estate, Bhubaneswar, India</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Compass className="h-4.5 w-4.5 text-pink-500 flex-shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-zinc-800 dark:text-zinc-200 block">Coordinates Geo-Tags</span>
                  <span className="text-[11px] font-mono leading-none">20.2961° N, 85.8245° E</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Calendar className="h-4.5 w-4.5 text-pink-500 flex-shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-zinc-800 dark:text-zinc-200 block">Estate Lounges Working Hours</span>
                  <span className="text-[11px] leading-snug">Tuesday - Sunday (Closed Mondays), 9:00 AM - 6:00 PM IST</span>
                </div>
              </div>
            </div>
          </div>

          {/* Visual card bento box */}
          <div className="bg-gradient-to-tr from-emerald-500/10 via-pink-400/5 to-transparent border border-neutral-200/50 dark:border-zinc-800 p-6 rounded-3xl relative overflow-hidden space-y-4">
            <h3 className="font-extrabold text-sm text-zinc-900 dark:text-white">Our Ecological Pledge</h3>
            <p className="text-[11px] text-zinc-500 leading-relaxed">
              We reject all toxic chemical fertilizer formulas and systemic growth hormones. Every blossom is hand-pollinated at midnight under giant solar trellises, ensuring optimal fruit-set values and dense moisture yields.
            </p>

            <ul className="space-y-2 pt-2 text-xs text-zinc-700 dark:text-zinc-300 font-medium">
              <li className="flex items-center gap-1.5">
                <CheckSquare className="h-4 w-4 text-emerald-600" />
                100% Organic compost enriched
              </li>
              <li className="flex items-center gap-1.5">
                <CheckSquare className="h-4 w-4 text-emerald-600" />
                Recycled drip-irrigation infrastructure
              </li>
              <li className="flex items-center gap-1.5">
                <CheckSquare className="h-4 w-4 text-emerald-600" />
                EcoCert biological farming standards
              </li>
            </ul>

            <img
              src="https://images.unsplash.com/photo-1516253593875-bd7ba052fbc5?w=500&auto=format&fit=crop"
              alt="Farmers potting organic soil compost"
              className="w-full h-36 object-cover rounded-2xl bg-neutral-100 border border-neutral-100 dark:border-zinc-800"
            />
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* SUB-TAB 2: CONTACT FORM FEEDBACKS */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'contact' && (
        <div className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800/60 p-6 rounded-3xl max-w-lg mx-auto space-y-4">
          <div className="flex items-center gap-2">
            <Mail className="h-5 w-5 text-pink-500 animate-pulse" />
            <h3 className="font-extrabold text-sm text-neutral-800 dark:text-zinc-100">Send Inquiry Message</h3>
          </div>

          <p className="text-zinc-500 dark:text-zinc-400 text-xs leading-relaxed">
            Have questions about wholesale restaurant supplies, grafting saplings, or reserving custom sunset events? Fill out this sandbox form to send a note to our farmhouse registry.
          </p>

          {sendSuccess ? (
            <div className="py-12 text-center text-xs space-y-3 bg-emerald-500/5 rounded-2xl p-4">
              <div className="h-10 w-10 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center">
                <Check className="h-5 w-5" />
              </div>
              <p className="font-bold text-emerald-700">Thank you! Your inquiries are safely logged.</p>
            </div>
          ) : (
            <form onSubmit={handleMessageSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label htmlFor="contact-sender-name" className="font-bold text-zinc-400 text-[10px] uppercase block">Your Full Name</label>
                  <input
                    id="contact-sender-name"
                    required
                    type="text"
                    value={senderName}
                    onChange={(e) => setSenderName(e.target.value)}
                    placeholder="Elena Petrova"
                    className="w-full p-2.5 bg-neutral-50 dark:bg-zinc-800 border-none outline-none focus:ring-1 focus:ring-pink-500 rounded-lg text-zinc-800 dark:text-zinc-200"
                  />
                </div>

                <div className="space-y-1">
                  <label htmlFor="contact-sender-email" className="font-bold text-zinc-400 text-[10px] uppercase block">Email Address</label>
                  <input
                    id="contact-sender-email"
                    required
                    type="email"
                    value={senderEmail}
                    onChange={(e) => setSenderEmail(e.target.value)}
                    placeholder="elena@gmail.com"
                    className="w-full p-2.5 bg-neutral-50 dark:bg-zinc-800 border-none outline-none focus:ring-1 focus:ring-pink-500 rounded-lg text-zinc-800 dark:text-zinc-200"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label htmlFor="contact-sender-text" className="font-bold text-zinc-400 text-[10px] uppercase block">Inquiry Narrative Description</label>
                <textarea
                  id="contact-sender-text"
                  required
                  rows={4}
                  value={senderText}
                  onChange={(e) => setSenderText(e.target.value)}
                  placeholder="I would love to learn more about scheduling a wedding ceremony beneath the blooming trellises next September..."
                  className="w-full p-2.5 bg-neutral-50 dark:bg-zinc-800 border-none outline-none focus:ring-1 focus:ring-pink-500 rounded-lg text-zinc-800 dark:text-zinc-200 resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={isSending}
                className="w-full py-3.5 rounded-full bg-pink-500 hover:bg-pink-600 text-white font-bold text-xs tracking-wide shadow-lg shadow-pink-500/10 flex items-center justify-center gap-2 cursor-pointer"
              >
                {isSending ? 'Transmitting sandbox packet...' : 'Transmit Inquiry Slot Note'}
              </button>
            </form>
          )}

        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* SUB-TAB 3: INBOUND MESSAGES INBOX LOG CHANNELS */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'inbox' && (userRole === 'Admin' || userRole === 'Farm Worker') && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-neutral-800 dark:text-white">Farmside Inbound Inquiries</h3>
            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">{messages.length} packages logged</span>
          </div>

          {messages.length === 0 ? (
            <div className="py-12 text-center text-zinc-400 text-xs">
              Inbound registry inbox empty.
            </div>
          ) : (
            <div className="space-y-3">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className="bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800 p-4 rounded-3xl text-xs space-y-2 relative shadow-sm"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="font-extrabold text-zinc-800 dark:text-zinc-100">{m.name}</span>
                      <span className="text-zinc-400 text-[10.5px] block font-medium">Email: {m.email}</span>
                      <span className="text-[9px] text-zinc-400">{new Date(m.createdAt).toLocaleString()}</span>
                    </div>

                    <button
                      onClick={() => handleDeleteMsg(m.id)}
                      className="p-1.5 text-zinc-400 hover:text-red-500 hover:bg-red-50/50 rounded-lg cursor-pointer"
                      title="Delete log"
                    >
                      <Trash className="h-4 w-4" />
                    </button>
                  </div>

                  <p className="text-zinc-600 dark:text-zinc-300 bg-neutral-50 dark:bg-zinc-950 p-2.5 rounded-xl border border-neutral-100 dark:border-zinc-850 whitespace-pre-line leading-relaxed text-[11px]">
                    {m.text}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

    </div>
  );
}
