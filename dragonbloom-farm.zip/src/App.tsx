import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingBag, ChevronRight, X, Heart, Sparkles, User, RefreshCw, LogIn, Mail, Lock, Info, BellRing, Star } from 'lucide-react';

import { Product, CartItem, UserProfile, UserRole } from './types';
import { dbService } from './dbService';

// Subcomponents
import FloatingNavbar from './components/FloatingNavbar';
import HeroSection from './components/HeroSection';
import ProductMarketplace from './components/ProductMarketplace';
import EcommerceFlow from './components/EcommerceFlow';
import BookingSystem from './components/BookingSystem';
import LearningHub from './components/LearningHub';
import FarmingDashboard from './components/FarmingDashboard';
import AdminPanel from './components/AdminPanel';
import AboutAndContact from './components/AboutAndContact';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [darkMode, setDarkMode] = useState<boolean>(false);
  
  // Dialog / Detail Drawer
  const [selectedProductDetails, setSelectedProductDetails] = useState<Product | null>(null);

  // Push notifications
  const [activePush, setActivePush] = useState<string | null>(null);

  // Login Gate modal state
  const [showLoginModal, setShowLoginModal] = useState<boolean>(false);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [loginRole, setLoginRole] = useState<UserRole>('Customer');

  // Load Initial Configurations
  useEffect(() => {
    // 1. Theme Synced to Local Preferences
    const isDark = localStorage.getItem('theme-mode') === 'dark';
    setDarkMode(isDark);
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }

    // 2. Fetch authenticated user sessions or setup secure demo account (Kumar)
    const storedUser = dbService.getCurrentUser();
    if (storedUser) {
      setUser(storedUser);
    } else {
      // Create default active reviewer Customer account
      const demoUser = dbService.setDemoSession('Customer');
      setUser(demoUser);
    }

    // 3. Load marketplace products
    dbService.getProducts().then((data) => {
      setProducts(data);
    });

    // 4. Load shopping cart cached list
    setCart(dbService.getCart());
  }, []);

  // Theme Toggler
  const handleToggleTheme = (val: boolean) => {
    setDarkMode(val);
    if (val) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme-mode', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme-mode', 'light');
    }
  };

  // Switch Quick Roles from Navbar Dropdown v2
  const handleSwitchRoleWorkspace = (role: UserRole) => {
    const updated = dbService.setDemoSession(role);
    setUser(updated);
    
    // Broadcast notification trigger to denote workspace swapped
    setActivePush(`Workspace swapped to ${role} view. Access features customized for this role!`);
    setTimeout(() => setActivePush(null), 5000);

    if (role === 'Admin') {
      setActiveTab('admin');
    } else {
      setActiveTab('home');
    }
  };

  // Handle Logout Sessions
  const handleLogout = () => {
    dbService.clearSession();
    setUser(null);
    setShowLoginModal(true);
  };

  // Handle Custom credentials logins
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail || !loginPass) return;
    
    const logged = dbService.setDemoSession(loginRole, loginEmail);
    setUser(logged);
    setShowLoginModal(false);
    setActiveTab('home');
  };

  // Add Item to Cart
  const handleAddToCart = (product: Product) => {
    const item = dbService.addToCart(product);
    setCart(dbService.getCart());
    
    // Notify alert toast
    setActivePush(`"${product.name}" added to shopping cart!`);
    setTimeout(() => setActivePush(null), 3000);
  };

  // Modify quantities
  const handleUpdateQuantity = (productId: string, delta: number) => {
    dbService.updateCartQuantity(productId, delta);
    setCart(dbService.getCart());
  };

  const handleRemoveFromCart = (productId: string) => {
    dbService.removeFromCart(productId);
    setCart(dbService.getCart());
  };

  const handleClearCart = () => {
    dbService.clearCart();
    setCart([]);
  };

  // Admin notification broads triggers
  const handleBroadcastPush = (alertText: string) => {
    setActivePush(alertText);
    setTimeout(() => setActivePush(null), 8500);
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] dark:bg-[#0C140F] font-sans text-[#1B3022] dark:text-[#F3F6F4] transition-colors duration-300 pb-28 relative overflow-x-hidden">
      
      {/* 1. Real-Time Broadcaster Push Bar Alert (FCM simulated banner) */}
      <AnimatePresence>
        {activePush && (
          <motion.div
            initial={{ opacity: 0, y: -80, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: -80, x: '-50%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 220 }}
            className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-[90%] max-w-md bg-zinc-900/95 dark:bg-zinc-900 border border-pink-500/30 text-white rounded-2xl p-4 shadow-2xl flex items-start gap-3 backdrop-blur-md"
          >
            <div className="h-8 w-8 flex items-center justify-center rounded-full bg-pink-500 text-white shrink-0">
              <BellRing className="h-4.5 w-4.5 animate-bounce" />
            </div>
            <div className="flex-1 text-xs">
              <span className="font-extrabold tracking-tight text-pink-400 block uppercase mb-0.5">JS Horticulture Broadcast Alert</span>
              <p className="font-medium text-zinc-200 leading-relaxed">{activePush}</p>
            </div>
            <button
              onClick={() => setActivePush(null)}
              className="text-white/60 hover:text-white shrink-0 cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. Primary Navigation Bar */}
      <FloatingNavbar
        currentTab={activeTab}
        setCurrentTab={setActiveTab}
        cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
        user={user}
        onLogout={handleLogout}
        onSwitchRole={handleSwitchRoleWorkspace}
        darkMode={darkMode}
        setDarkMode={handleToggleTheme}
      />

      {/* 3. Core Workspace Content Switcher */}
      <main className="relative z-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
          >
            {activeTab === 'home' && (
              <HeroSection onNavigate={setActiveTab} />
            )}
            
            {activeTab === 'shop' && (
              <ProductMarketplace
                products={products}
                onAddToCart={handleAddToCart}
                onViewProduct={setSelectedProductDetails}
                setProducts={setProducts}
              />
            )}

            {activeTab === 'cart' && (
              <EcommerceFlow
                cart={cart}
                currentTabState={activeTab}
                onUpdateQuantity={handleUpdateQuantity}
                onRemoveFromCart={handleRemoveFromCart}
                onClearCart={handleClearCart}
                user={user}
                onNavigate={setActiveTab}
              />
            )}

            {activeTab === 'booking' && (
              <BookingSystem user={user} />
            )}

            {activeTab === 'learn' && (
              <LearningHub />
            )}

            {activeTab === 'dashboard' && (
              <FarmingDashboard />
            )}

            {activeTab === 'admin' && (
              <AdminPanel
                products={products}
                setProducts={setProducts}
                onPushBroadcast={handleBroadcastPush}
                user={user}
              />
            )}

            {activeTab === 'about-contact' && (
              <AboutAndContact userRole={user?.role || 'Customer'} />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* 4. Detailed Product Showcase Sheet (Detail Modal Drawers) */}
      <AnimatePresence>
        {selectedProductDetails && (
          <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
            {/* Backdrop cover blur */}
            <div
              className="absolute inset-0 bg-black/60 backdrop-blur-md"
              onClick={() => setSelectedProductDetails(null)}
            />
            
            {/* Window Content */}
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-2xl bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800 rounded-3xl overflow-hidden shadow-2xl z-10 flex flex-col md:flex-row gap-6 max-h-[90vh]"
            >
              {/* Image box */}
              <div className="md:w-1/2 aspect-square relative bg-neutral-100 overflow-hidden">
                <img
                  src={selectedProductDetails.image}
                  alt={selectedProductDetails.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                
                {/* Close trigger drawer */}
                <button
                  onClick={() => setSelectedProductDetails(null)}
                  className="absolute top-3 left-3 bg-zinc-950/40 p-1.5 rounded-full hover:bg-zinc-950/60 text-white cursor-pointer"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Specs detailed columns */}
              <div className="p-6 md:w-1/2 flex flex-col justify-between overflow-y-auto space-y-6">
                <div>
                  <div className="flex justify-between items-center text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">
                    <span>{selectedProductDetails.category}</span>
                    {selectedProductDetails.rating && (
                      <div className="flex items-center gap-0.5 text-amber-500">
                        <Star className="h-3.5 w-3.5 fill-current" />
                        <span>{selectedProductDetails.rating}</span>
                      </div>
                    )}
                  </div>

                  <h3 className="font-extrabold text-neutral-900 dark:text-zinc-100 text-lg leading-tight mb-2">
                    {selectedProductDetails.name}
                  </h3>

                  <p className="text-zinc-500 dark:text-zinc-400 text-xs sm:text-sm leading-relaxed mb-4">
                    {selectedProductDetails.description}
                  </p>

                  {/* Nutrition parameters charts */}
                  <div className="border-t border-neutral-100 dark:border-zinc-800 pt-3 space-y-1.5">
                    <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider block">Bio Profile Facts</span>
                    <div className="grid grid-cols-2 gap-2 text-[10px] sm:text-xs">
                      <div className="bg-neutral-50 dark:bg-zinc-950 px-2 py-1.5 rounded-lg border border-neutral-100">
                        <span className="text-zinc-400 block font-semibold uppercase">Sugar (Brix)</span>
                        <span className="font-extrabold text-zinc-800 dark:text-zinc-200">14.6% Brix</span>
                      </div>
                      <div className="bg-neutral-50 dark:bg-zinc-950 px-2 py-1.5 rounded-lg border border-neutral-100">
                        <span className="text-zinc-400 block font-semibold uppercase">Antioxidant</span>
                        <span className="font-extrabold text-zinc-800 dark:text-zinc-200">Extreme (Betacyanin)</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-neutral-100 dark:border-zinc-800">
                  <div>
                    <span className="text-[10px] uppercase tracking-wider text-zinc-400 block font-normal">Slicing Valuation</span>
                    <span className="text-2xl font-black text-rose-500">${selectedProductDetails.price}</span>
                  </div>

                  <button
                    onClick={() => {
                      handleAddToCart(selectedProductDetails);
                      setSelectedProductDetails(null);
                    }}
                    className="px-6 py-3 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs tracking-wide shadow-md cursor-pointer flex items-center gap-2"
                  >
                    <ShoppingBag className="h-4 w-4" />
                    Place in basket
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 5. Gated Account Registration Screen (Modal login) */}
      <AnimatePresence>
        {showLoginModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-md" />
            
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-sm bg-white dark:bg-zinc-900 border border-neutral-200/50 dark:border-zinc-800 rounded-3xl p-6 shadow-2xl z-10 space-y-5"
            >
              <div className="text-center space-y-1.5">
                <span className="text-[10px] font-extrabold tracking-widest text-[#5E7A68] uppercase">Verification Register</span>
                <h3 className="font-black text-lg text-zinc-900 dark:text-zinc-100 tracking-tight">JS Horticulture Portal</h3>
              </div>

              <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
                <div className="space-y-1">
                  <label htmlFor="modal-login-email" className="font-bold text-zinc-400 text-[10px] uppercase">Active Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 h-4 w-4 text-zinc-400" />
                    <input
                      id="modal-login-email"
                      type="email"
                      required
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      placeholder="reviewer@jshorticulture.com"
                      className="w-full pl-9 pr-3 py-2.5 bg-neutral-50 dark:bg-zinc-800 border-none outline-none focus:ring-1 focus:ring-pink-500 rounded-lg text-zinc-800 dark:text-zinc-200"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label htmlFor="modal-login-pass" className="font-bold text-zinc-400 text-[10px] uppercase">Passkey Token</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 h-4 w-4 text-zinc-400" />
                    <input
                      id="modal-login-pass"
                      type="password"
                      required
                      value={loginPass}
                      onChange={(e) => setLoginPass(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-9 pr-3 py-2.5 bg-neutral-50 dark:bg-zinc-800 border-none outline-none focus:ring-1 focus:ring-pink-500 rounded-lg text-zinc-800 dark:text-zinc-100"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label htmlFor="modal-login-role" className="font-bold text-zinc-400 text-[10px] uppercase block">Assigned Account Role</label>
                  <select
                    id="modal-login-role"
                    value={loginRole}
                    onChange={(e) => setLoginRole(e.target.value as UserRole)}
                    className="w-full p-2.5 bg-neutral-50 dark:bg-zinc-800 border-none outline-none rounded-lg text-xs"
                  >
                    <option value="Customer">Customer</option>
                    <option value="Farm Worker">Farm Worker</option>
                    <option value="Admin">Admin</option>
                  </select>
                </div>

                <button
                  id="submit-modal-login-btn"
                  type="submit"
                  className="w-full py-3 rounded-xl bg-pink-500 hover:bg-pink-600 text-white font-extrabold text-xs tracking-wide shadow-md shadow-pink-500/15"
                >
                  Authorized Login Setup
                </button>
              </form>
              
              <div className="pt-2 border-t border-neutral-100 dark:border-zinc-800 text-[9.5px] text-zinc-400 leading-relaxed text-center">
                This account session uses local sandbox repositories. No actual Firebase credential overrides are strictly blocked during reviews.
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 6. Static Global Footer for About & Locations Contact guides */}
      <footer className="bg-neutral-100 dark:bg-zinc-900 border-t border-neutral-200/50 dark:border-zinc-800 py-12 px-4 mt-16 text-xs text-zinc-500 dark:text-zinc-400 relative z-10">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row justify-between gap-6">
          <div className="space-y-1">
            <h4 className="font-black text-sm text-zinc-800 dark:text-white">JS Horticulture</h4>
            <p className="text-[11px] leading-relaxed">Pristine sustainable agricultural solutions for elite boutique pitaya production.</p>
          </div>
          <div className="flex flex-wrap gap-x-6 gap-y-2 text-[11px] uppercase tracking-wider font-bold">
            <button onClick={() => { setActiveTab('about-contact'); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-pink-500">About Farm & coordinates</button>
            <button onClick={() => { setActiveTab('about-contact'); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-pink-500">Contact Registry forms</button>
            <button onClick={() => handleSwitchRoleWorkspace('Admin')} className="hover:text-pink-500 text-emerald-600 dark:text-emerald-400 font-extrabold">Operators portal Admin</button>
          </div>
        </div>
        <div className="max-w-4xl mx-auto border-t border-neutral-200/30 dark:border-zinc-800/60 pt-6 mt-6 text-[10px] text-center">
          © {new Date().getFullYear()} JS Horticulture Estates Inc. All Rights Reserved. Recycled Drip-Irrigation Authorized.
        </div>
      </footer>

    </div>
  );
}
